'''
导入模块

'''
import torch
import numpy as np
import math
from torch.optim.lr_scheduler import LambdaLR
import argparse
from train import train, test
from typing import Tuple,List;
Tuple[str, int]
from model.get_model import get_model
from torch.utils.data import Dataset, DataLoader
from utils.DSF.dataset import *
from utils.DSF.utils import *

from torch.utils.tensorboard import SummaryWriter
from utils.setup_logger import setup_logger
from utils.visual_predict import visualize_predict
from utils.evaluation import Evaluator

import time as t
from torchsummaryX import summary
# from calflops import calculate_flops
from thop import profile

def train_and_eval(patch_size, lr, batch_size, weight_decay, model_index):

    # 调度器
    def get_warmup_cosine_schedule(
            optimizer,
            warmup_epochs=5,  # 预热 epoch 数
            total_epochs=100,  # 总训练 epoch 数
            warmup_start_lr=0.0,  # 预热起始学习率
            base_lr=0.001,  # 预热结束学习率（一般等于 optimizer.lr）
            eta_min=0.0  # 余弦衰减最低学习率
    ):
        def lr_lambda(current_epoch):
            # -------- 1. Linear Warmup （线性预热）--------
            if current_epoch < warmup_epochs:
                return (warmup_start_lr +
                        (base_lr - warmup_start_lr) * (current_epoch / warmup_epochs)
                        ) / base_lr

            # -------- 2. Cosine Annealing （余弦退火）--------
            progress = (current_epoch - warmup_epochs) / (total_epochs - warmup_epochs)
            cosine_factor = eta_min / base_lr + 0.5 * (1 - eta_min / base_lr) * (1 + math.cos(math.pi * progress))
            return cosine_factor

        return LambdaLR(optimizer, lr_lambda)

    # 可视化预测结果
    def vis_a_image(gt_vis, pred_vis, save_single_predict_path, save_single_gt_path, only_vis_label=False):
        visualize_predict(gt_vis, pred_vis, save_single_predict_path, save_single_gt_path,
                          only_vis_label=only_vis_label)
        visualize_predict(gt_vis, pred_vis, save_single_predict_path.replace('.png', '_mask.png'), save_single_gt_path,
                          only_vis_label=True)

    def setup_seed(seed):
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        os.environ['PYTHONHASHSEED'] = str(seed)
        np.random.seed(seed)
        random.seed(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    # 命令行参数解析
    def get_parser(patch_size, lr, batch_size, weight_decay, model_index):
        parser = argparse.ArgumentParser()

        # 数据
        parser.add_argument('--dataset_index', type=int, default=0)     # 默认值从0改到3，对应83行，选择
        parser.add_argument('--patch_train_size', type=int, default=patch_size)
        parser.add_argument('--patch_test_size', type=int, default=patch_size)
        parser.add_argument('--train_samples', type=int, default=30)    # 每个类别的训练样本数量
        # parser.add_argument('--val_samples', type=float, default=0.02)  # 每个类别的训练样本数量
        parser.add_argument('--val_samples', type=float, default=0)  # 每个类别的训练样本数量
        parser.add_argument('--use_pca', type=bool, default=False)
        parser.add_argument("--pc", type=int, default=30)

        # 路径和名称
        parser.add_argument('--data_set_path', type=str, default='./data')
        parser.add_argument('--work_dir', type=str, default='/spaspemamba__code/output')
        # parser.add_argument('--net_name', type=str, default='MambaHSI')
        parser.add_argument('--exp_name', type=str, default='test_channel_128')

        # 模型
        # parser.add_argument('--SSAS', type=List, default=['b c t h w', 'b h w c t'])
        # parser.add_argument('--channel', type=int, default=128)
        # parser.add_argument('--num_layer', type=int, default=2)
        parser.add_argument('--model_index', type=int, default=model_index)
        parser.add_argument('--model_name', type=str, default='spaspemamba')
        # parser.add_argument('--model_name', type=str, default='gscvit')

        # 超参数
        parser.add_argument('--lr', type=float, default=lr)
        parser.add_argument('--weight_decay', type=float, default=weight_decay)
        # parser.add_argument('--lr', type=List, default=[0.0005, 0.0004, 0.0006, 0.0007])
        parser.add_argument('--batch_size', type=int, default=batch_size)
        parser.add_argument('--batch_test_size', type=int, default=256)
        parser.add_argument('--max_epoch', type=int, default=300)
        parser.add_argument('--patience', type=int, default=120)

        # 其他
        parser.add_argument('--record_computecost', type=bool, default=False)  # 是否记录计算成本(如FLOPs、参数量等)
        parser.add_argument('--is_val', type=bool, default=False)  # 是否在测试时使用验证集保存的最佳模型

        args = parser.parse_args()
        return args

    # 传回参数
    args = get_parser(patch_size, lr, batch_size, weight_decay, model_index)

    # 设置种子列表
    seed_list = [1, 11, 111, 1111, 11111, 111111, 1111111, 11111111, 111111111, 1111111111]
    # seed_list = [1]

    # 采样情况
    num_list = [args.train_samples, args.val_samples]

    # 设置设备
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    # 选择数据集
    data_set_name_list = ['UP', 'HanChuan', 'HongHu', 'Houston']
    data_name = data_set_name_list[args.dataset_index]

    # 保存路径
    if args.model_name == 'spaspemamba':
        concrete = f'train_samples:{args.train_samples}_patch_size:{patch_size}_lr:{lr}_batch_size:{batch_size}'
        save_folder = os.path.join(args.work_dir, args.model_name, data_name, args.exp_name, str(args.model_index), concrete)
    else:
        concrete = f'train_samples:{args.train_samples}_patch_size:{patch_size}_lr:{lr}_batch_size:{batch_size}'
        save_folder = os.path.join(args.work_dir, args.model_name, data_name, args.exp_name,
                                   concrete)

    if not os.path.exists(save_folder):
        os.makedirs(save_folder)
        print("makedirs {}".format(save_folder))
    # 设置日志系统
    save_log_path = os.path.join(save_folder, 'train_tr{}_val{}.log'.format(num_list[0], num_list[1]))
    logger = setup_logger(name='{}'.format(data_name), logfile=save_log_path)  # 初始化日志记录器

    logger.info(patch_size, lr, batch_size)

    # 加载数据集
    image, gt, labels = load_mat_hsi(data_name, args.data_set_path)
    X = torch.tensor(image).unsqueeze(0).permute(0, 3, 1, 2)

    # 获取数据维度信息
    height, width, time = X.shape[2], X.shape[3], X.shape[1]

    # 计算类别数量（通过统计唯一标签值）
    class_count = len(labels)

    # 初始化结果存储列表
    OA_ALL = []
    AA_ALL = []
    KPP_ALL = []
    EACH_ACC_ALL = []
    train_times = []
    test_times = []
    times = []

    # 对每个随机种子进行实验
    for exp_idx, curr_seed in enumerate(seed_list):
        # 时间记录
        start_time = t.time()
        start_time_train = t.time()

        # 设置日志系统
        writer = SummaryWriter(log_dir=f"/{save_folder}/RUNS/{curr_seed}", filename_suffix="exp1")

        # 设置随机种子
        setup_seed(curr_seed)
        # 创建单次实验的名称和文件夹
        single_experiment_name = 'run{}_seed{}'.format(str(exp_idx), str(curr_seed))
        save_single_experiment_folder = os.path.join(save_folder, single_experiment_name)

        if not os.path.exists(save_single_experiment_folder):
            os.mkdir(save_single_experiment_folder)

        # 创建可视化结果保存文件夹
        save_vis_folder = os.path.join(save_single_experiment_folder, 'vis')
        if not os.path.exists(save_vis_folder):
            os.makedirs(save_vis_folder)
            print("makedirs {}".format(save_vis_folder))

        # 设置各种保存路径
        save_weight_path = os.path.join(save_single_experiment_folder,
                                        "best_tr{}_val{}.pth".format(num_list[0], num_list[1]))
        results_save_path = os.path.join(save_single_experiment_folder,
                                         'result_tr{}_val{}.txt'.format(num_list[0], num_list[1]))
        predict_save_path = os.path.join(save_single_experiment_folder,
                                         'pred_vis_tr{}_val{}.png'.format(num_list[0], num_list[1]))
        gt_save_path = os.path.join(save_single_experiment_folder,
                                    'gt_vis_tr{}_val{}.png'.format(num_list[0], num_list[1]))


        if args.val_samples != 0:
            # 进行数据采样，获取训练、验证和测试集的索引
            train_gt, val_gt, test_gt = sample_gt_by_class(gt, args.train_samples, args.val_samples, curr_seed)
            # train_gt, test_gt = sample_gt_by_class(gt, args.train_samples, args.val_samples, curr_seed)

            train_set = HSIDataset(image, train_gt, patch_size=args.patch_train_size, data_aug=True, use_pca=args.use_pca,
                                   pc=args.pc)
            val_set = HSIDataset(image, val_gt, patch_size=args.patch_train_size, data_aug=True, use_pca=args.use_pca,
                                 pc=args.pc)

            train_loader = torch.utils.data.DataLoader(train_set, args.batch_size, drop_last=False, shuffle=True)
            val_loader = torch.utils.data.DataLoader(val_set, 32, drop_last=False, shuffle=False)
        else:
            train_gt, test_gt = sample_gt_by_class(gt, args.train_samples, args.val_samples, curr_seed)
            train_set = HSIDataset(image, train_gt, patch_size=args.patch_train_size, data_aug=True,
                                   use_pca=args.use_pca,
                                   pc=args.pc)
            train_loader = torch.utils.data.DataLoader(train_set, args.batch_size, drop_last=False, shuffle=True)
            val_loader = None

        # 打印各类采样数量
        if exp_idx == 0:
            split_info_print(train_gt, test_gt, labels)

        train_gt = torch.from_numpy(train_gt).type(torch.FloatTensor).to(device)
        test_gt = torch.from_numpy(test_gt).type(torch.FloatTensor).to(device)

        # # 模型
        net = get_model(args.model_name, data_name, args.patch_train_size, time, class_count, args.model_index, device)
        net.to(device)

        # ====================================================
        # 在第一次实验时计算四项核心指标 (#Param, Memory, FLOPS, Time)
        # ====================================================
        if exp_idx == 0:
            print(f"\n======== 正在计算模型指标 (Model Index: {args.model_index}) ========")
            net.eval()

            # 1. 定义虚拟输入
            # 根据你原有代码中注释掉的 summary 部分，输入形状似乎是 (1, 1, time, patch_size, patch_size)
            # 如果报错，请根据你的模型实际 forward 接收的维度调整这里
            dummy_input = torch.randn(1, 1, time, args.patch_train_size, args.patch_train_size).to(device)

            # 2. 计算 #Param 和 FLOPS
            macs, params = profile(net, inputs=(dummy_input,), verbose=False)
            flops_g = 2 * macs / 1e9  # 转换为 GFLOPS
            params_m = params / 1e6  # 转换为 M

            for m in net.modules():
                # 清除残留的属性
                if hasattr(m, "total_ops"):
                    del m.total_ops
                if hasattr(m, "total_params"):
                    del m.total_params
                # 强制清空 forward hooks
                m._forward_hooks.clear()

            # 3. 计算 Memory (峰值显存)
            torch.cuda.reset_peak_memory_stats()
            with torch.no_grad():
                _ = net(dummy_input)
            memory_mb = torch.cuda.max_memory_allocated() / (1024 ** 2)

            # 4. 计算 Inference Time (推理耗时)
            # 预热
            for _ in range(50):
                with torch.no_grad():
                    _ = net(dummy_input)

            # 测速
            iter_times = 100
            torch.cuda.synchronize()
            t_start = t.time()
            with torch.no_grad():
                for _ in range(iter_times):
                    _ = net(dummy_input)
            torch.cuda.synchronize()
            inference_time_ms = (t.time() - t_start) / iter_times * 1000

            # 打印并记录日志
            metrics_str = (
                f"\n----------------------------------------\n"
                f"Model Metrics:\n"
                f"1. #Param.: {params_m:.2f} M\n"
                f"2. Memory : {memory_mb:.2f} MB\n"
                f"3. FLOPS  : {flops_g:.2f} G\n"
                f"4. Time   : {inference_time_ms:.2f} ms\n"
                f"----------------------------------------\n"
            )
            print(metrics_str)
            logger.info(metrics_str)

            # 恢复训练模式
            net.train()

        # ===================== 优化器（Adam） ======================
        # optimizer = torch.optim.Adam(
        #     net.parameters(),
        #     lr=args.lr,
        #     weight_decay=0
        # )
        optimizer = torch.optim.AdamW(
            net.parameters(),
            lr=args.lr,
            weight_decay=args.weight_decay,
            betas=(0.9, 0.999)
        )

        # ===================== 阶梯式下降调度器 ======================
        # scheduler = torch.optim.lr_scheduler.MultiStepLR(
        #     optimizer,
        #     milestones=[75, 112],  # 在第 100 和 150 轮衰减
        #     gamma=0.3  # 乘以 0.3
        # )
        scheduler = None
        # scheduler = get_warmup_cosine_schedule(
        #     optimizer,
        #     warmup_epochs=10,
        #     total_epochs=100,
        #     warmup_start_lr=0.0,
        #     base_lr=args.lr,
        #     eta_min=1e-4
        # )

        # ===================== 损失函数 ======================
        loss_func = torch.nn.CrossEntropyLoss()

        '''
        开始训练
        
        '''
        train(net, optimizer, loss_func, train_loader, val_loader, args.max_epoch, save_weight_path, device, scheduler, logger, writer, args.patience)

        end_time_train = t.time()
        train_times.append(end_time_train - start_time_train)  # train time

        '''
        开始测试

        '''
        start_time_test = t.time()

        if args.use_pca == True:
            original_shape = image.shape
            reshaped_image = image.reshape(-1, original_shape[2])
            pca = PCA(n_components=args.pc)
            pca_result = pca.fit_transform(reshaped_image)
            image = pca_result.reshape(original_shape[0], original_shape[1], args.pc)

        probabilities = test(net, class_count, args.model_index, save_weight_path, image, args.patch_test_size, class_count, device, time, args.batch_test_size, args.is_val)

        # 测试时间
        end_time_test = t.time()
        test_times.append(end_time_test - start_time_test)

        # 一次实验总时间
        end_time = t.time()
        times.append(end_time - start_time)

        prediction = np.argmax(probabilities, axis=-1)
        prediction = torch.from_numpy(prediction)

        '''
        开始评估

        '''
        # 初始化评估器
        test_evaluator = Evaluator(num_class=class_count)

        final_pred = prediction.unsqueeze(0)
        # 调整输出尺寸以匹配标签
        # y_test = test_gt.unsqueeze(0)  # 增加批次维度
        Y_test_np = test_gt.cpu().numpy()
        Y_test_255 = np.where(Y_test_np == -1, 255, Y_test_np)  # 将忽略标签转为255

        # 添加批次数据到评估器
        test_evaluator.add_batch(np.expand_dims(Y_test_255, axis=0), final_pred.cpu().numpy().astype(np.int64))

        # 计算各种评估指标
        OA_test = test_evaluator.Pixel_Accuracy()  # 总体精度
        mIOU_test, IOU_test = test_evaluator.Mean_Intersection_over_Union()  # 交并比
        mAcc_test, Acc_test = test_evaluator.Pixel_Accuracy_Class()  # 类别精度
        Kappa_test = test_evaluator.Kappa()  # Kappa系数

        # 记录测试结果
        logger.info(
            'Test {}|OA:{}|MACC:{}|Kappa:{}|MIOU:{}|IOU:{}|ACC:{}'.format(args.max_epoch, OA_test, mAcc_test, Kappa_test,
                                                                          mIOU_test, IOU_test,
                                                                          Acc_test))
        gt_1 = gt + 1
        vis_a_image(gt_1, final_pred.cpu().numpy(), predict_save_path, gt_save_path)

        # 打开结果文件并追加本次实验结果
        # Output infors
        f = open(results_save_path, 'a+')
        str_results = '\n======================' \
                      + " exp_idx=" + str(exp_idx) \
                      + " seed=" + str(curr_seed) \
                      + " learning rate=" + str(args.lr) \
                      + " epochs=" + str(args.max_epoch) \
                      + " train ratio=" + str(args.train_samples) \
                      + " val ratio=" + str(args.val_samples) \
                      + " ======================" \
                      + "\nOA=" + str(OA_test) \
                      + "\nAA=" + str(mAcc_test) \
                      + '\nkpp=' + str(Kappa_test) \
                      + '\nmIOU_test:' + str(mIOU_test) \
                      + "\nIOU_test:" + str(IOU_test) \
                      + "\nAcc_test:" + str(Acc_test) + "\n"

        logger.info(str_results)  # 记录到日志
        f.write(str_results)  # 写入文件
        f.close()  # 关闭文件

        # 将本次实验结果添加到总列表中
        OA_ALL.append(OA_test)  # 总体精度
        AA_ALL.append(mAcc_test)  # 平均精度
        KPP_ALL.append(Kappa_test)  # Kappa系数
        EACH_ACC_ALL.append(Acc_test)  # 各类别精度

        torch.cuda.empty_cache()  # 清理GPU缓存

        # 关闭日志系统
        writer.close()

    # 将列表转换为numpy数组以便计算统计量
    OA_ALL = np.array(OA_ALL)
    AA_ALL = np.array(AA_ALL)
    KPP_ALL = np.array(KPP_ALL)
    EACH_ACC_ALL = np.array(EACH_ACC_ALL)
    train_times = np.array(train_times)
    test_times = np.array(test_times)
    times = np.array(times)

    # 设置numpy输出精度
    np.set_printoptions(precision=4)

    # 记录多次实验的平均结果和标准差
    logger.info("\n====================Mean result of {} times runs =========================".format(len(seed_list)))
    logger.info('List of OA: %s', list(OA_ALL))
    logger.info('List of AA: %s', list(AA_ALL))
    logger.info('List of KPP: %s', list(KPP_ALL))
    # 计算并记录平均值和标准差
    logger.info('OA= %f %s %f', round(np.mean(OA_ALL) * 100, 2), '+-', round(np.std(OA_ALL) * 100, 2))
    logger.info('AA= %f %s %f', round(np.mean(AA_ALL) * 100, 2), '+-', round(np.std(AA_ALL) * 100, 2))
    logger.info('Kpp= %f %s %f', round(np.mean(KPP_ALL) * 100, 2), '+-', round(np.std(KPP_ALL) * 100, 2))
    logger.info('Acc per class= %s %s %s', np.round(np.mean(EACH_ACC_ALL, 0) * 100, decimals=2), '+-',
                np.round(np.std(EACH_ACC_ALL, 0) * 100, decimals=2))

    # logger.info("Average training time= %f %s %f", round(np.mean(Train_Time_ALL), 2), '+-', round(np.std(Train_Time_ALL), 3))
    # logger.info("Average testing time= %f %s %f", round(np.mean(Test_Time_ALL) * 1000, 2), '+-',
    #       round(np.std(Test_Time_ALL) * 1000, 3))

    # Output infors
    # 创建平均结果文件
    mean_result_path = os.path.join(save_folder, 'mean_result.txt')
    f = open(mean_result_path, 'w')
    # str_results = '\n\n***************Mean result of ' + str(len(seed_list)) + 'times runs ********************' \
    #               + '\nList of OA:' + str(list(OA_ALL)) \
    #               + '\nList of AA:' + str(list(AA_ALL)) \
    #               + '\nList of KPP:' + str(list(KPP_ALL)) \
    #               + '\nOA=' + str(round(np.mean(OA_ALL) * 100, 2)) + '+-' + str(round(np.std(OA_ALL) * 100, 2)) \
    #               + '\nAA=' + str(round(np.mean(AA_ALL) * 100, 2)) + '+-' + str(round(np.std(AA_ALL) * 100, 2)) \
    #               + '\nKpp=' + str(round(np.mean(KPP_ALL) * 100, 2)) + '+-' + str(
    #     round(np.std(KPP_ALL) * 100, 2)) \
    #               + '\nAcc per class=\n' + str(np.round(np.mean(EACH_ACC_ALL, 0) * 100, 2)) + '+-' + str(
    #     np.round(np.std(EACH_ACC_ALL, 0) * 100, 2)) \
    #               + "\nAverage training time=" + str(
    #     np.round(np.mean(Train_Time_ALL), decimals=2)) + '+-' + str(
    #     np.round(np.std(Train_Time_ALL), decimals=3)) \
    #               + "\nAverage testing time=" + str(
    #     np.round(np.mean(Test_Time_ALL) * 1000, decimals=2)) + '+-' + str(
    #     np.round(np.std(Test_Time_ALL) * 100, decimals=3))
    str_results = '\n\n***************Mean result of ' + str(len(seed_list)) + 'times runs ********************' \
                  + '\nList of OA:' + str(list(OA_ALL)) \
                  + '\nList of AA:' + str(list(AA_ALL)) \
                  + '\nList of KPP:' + str(list(KPP_ALL)) \
                  + '\nOA=' + str(round(np.mean(OA_ALL) * 100, 2)) + '+-' + str(round(np.std(OA_ALL) * 100, 2)) \
                  + '\nAA=' + str(round(np.mean(AA_ALL) * 100, 2)) + '+-' + str(round(np.std(AA_ALL) * 100, 2)) \
                  + '\nKpp=' + str(round(np.mean(KPP_ALL) * 100, 2)) + '+-' + str(round(np.std(KPP_ALL) * 100, 2)) \
                  + '\nAcc per class=\n' + str(np.round(np.mean(EACH_ACC_ALL, 0) * 100, 2)) + '+-' + str(
        np.round(np.std(EACH_ACC_ALL, 0) * 100, 2)) \
                  + '\nList of train_times:' + str(list(train_times)) \
                  + '\nList of test_times:' + str(list(test_times)) \
                  + '\nList of times:' + str(list(times)) \
                  + '\ntrain_times=' + str(round(np.mean(train_times) * 1, 2)) + '+-' + str(round(np.std(train_times) * 1, 2)) \
                  + '\ntest_times=' + str(round(np.mean(test_times) * 1, 2)) + '+-' + str(round(np.std(test_times) * 1, 2)) \
                  + '\ntimes=' + str(round(np.mean(times) * 1, 2)) + '+-' + str(round(np.std(times) * 1, 2))

    f.write(str_results)
    f.close()

    del net

    return np.mean(KPP_ALL)


if __name__ == "__main__":
    lr = 0.0004
    patch_size = 11
    batch_size = 32
    weight_decay = 0.00001
    model_index = 8
    result = train_and_eval(patch_size, lr, batch_size, weight_decay, model_index)

    print(result)





