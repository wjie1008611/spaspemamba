import numpy as np
from sklearn.cluster import KMeans

def spatial_uniform_sampling_1d(gt, H, W, train_per_class=30, val_per_class=10, n_clusters=5):
    """
    适配你当前的1D gt格式：
    输入：
        gt: 1D 或 2D numpy array
        H, W: 图像高宽
    输出：
        train_idx, val_idx, test_idx (全部是 1D index)
    """

    # ----- 处理 gt（可能为 1D） -----
    if gt.ndim == 1:
        gt_2d = gt.reshape(H, W)
    else:
        gt_2d = gt

    label_ids = np.unique(gt_2d)
    label_ids = label_ids[label_ids != 0]  # 去掉背景

    train_idx, val_idx, test_idx = [], [], []

    for cls in label_ids:

        # 找到该类的所有 2D 像素坐标 (x,y)
        coords = np.column_stack(np.where(gt_2d == cls))
        N = coords.shape[0]

        # 类别样本太少情况
        if N <= train_per_class + val_per_class:
            np.random.shuffle(coords)
            train_coords = coords[:train_per_class]
            val_coords   = coords[train_per_class:train_per_class+val_per_class]
            test_coords  = coords[train_per_class+val_per_class:]

        else:
            # ----------- 类内空间聚类 ------------
            k = min(n_clusters, N)
            kmeans = KMeans(n_clusters=k, n_init='auto').fit(coords)

            sample_per_cluster = max(1, train_per_class // k)
            train_list = []

            for cid in range(k):
                cluster_coords = coords[kmeans.labels_ == cid]
                np.random.shuffle(cluster_coords)

                take = min(sample_per_cluster, len(cluster_coords))
                train_list.extend(cluster_coords[:take])

            train_list = np.array(train_list)

            # 剩余像素划分 val & test
            used = set([tuple(c) for c in train_list])
            remain = np.array([c for c in coords if tuple(c) not in used])
            np.random.shuffle(remain)

            val_list  = remain[:val_per_class]
            test_list = remain[val_per_class:]

            train_coords = train_list
            val_coords   = val_list
            test_coords  = test_list

        # 将 2D 坐标转回 1D 索引
        train_idx += [x * W + y for x, y in train_coords]
        val_idx   += [x * W + y for x, y in val_coords]
        test_idx  += [x * W + y for x, y in test_coords]

    return train_idx, val_idx, test_idx
