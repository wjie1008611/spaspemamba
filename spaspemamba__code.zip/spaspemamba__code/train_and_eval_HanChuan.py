'''
导入模块

'''
import torch
import numpy as np
import math
from torch.optim.lr_scheduler import LambdaLR
import argparse
from train import train, test
from typing import Tuple,List;
Tuple[str, int]
from model.SpaSpeMamba_3 import SpaSpeMamba
from torch.utils.data import Dataset, DataLoader
from utils.DSF.dataset import *
from utils.DSF.utils import *

from torch.utils.tensorboard import SummaryWriter
from utils.setup_logger import setup_logger
from utils.visual_predict import visualize_predict
from utils.evaluation import Evaluator


def train_and_eval(patch_size, lr, batch_size, weight_decay, model_index):

    # 调度器
    def get_warmup_cosine_schedule(
            optimizer,
            warmup_epochs=5,  # 预热 epoch 数
            total_epochs=100,  # 总训练 epoch 数
            warmup_start_lr=0.0,  # 预热起始学习率
            base_lr=0.001,  # 预热结束学习率（一般等于 optimizer.lr）
            eta_min=0.0  # 余弦衰减最低学习率
    ):
        def lr_lambda(current_epoch):
            # -------- 1. Linear Warmup （线性预热）--------
            if current_epoch < warmup_epochs:
                return (warmup_start_lr +
                        (base_lr - warmup_start_lr) * (current_epoch / warmup_epochs)
                        ) / base_lr

            # -------- 2. Cosine Annealing （余弦退火）--------
            progress = (current_epoch - warmup_epochs) / (total_epochs - warmup_epochs)
            cosine_factor = eta_min / base_lr + 0.5 * (1 - eta_min / base_lr) * (1 + math.cos(math.pi * progress))
            return cosine_factor

        return LambdaLR(optimizer, lr_lambda)

    # 可视化预测结果
    def vis_a_image(gt_vis, pred_vis, save_single_predict_path, save_single_gt_path, only_vis_label=False):
        visualize_predict(gt_vis, pred_vis, save_single_predict_path, save_single_gt_path,
                          only_vis_label=only_vis_label)
        visualize_predict(gt_vis, pred_vis, save_single_predict_path.replace('.png', '_mask.png'), save_single_gt_path,
                          only_vis_label=True)

    def setup_seed(seed):
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        os.environ['PYTHONHASHSEED'] = str(seed)
        np.random.seed(seed)
        random.seed(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    # 命令行参数解析
    def get_parser(patch_size, lr, batch_size, weight_decay, model_index):
        parser = argparse.ArgumentParser()

        # 数据
        parser.add_argument('--dataset_index', type=int, default=1)  # 默认值从0改到3，对应83行，选择
        parser.add_argument('--patch_train_size', type=int, default=patch_size)
        parser.add_argument('--patch_test_size', type=int, default=patch_size)
        parser.add_argument('--train_samples', type=int, default=50)  # 每个类别的训练样本数量
        parser.add_argument('--val_samples', type=float, default=0.002)  # 每个类别的训练样本数量
        parser.add_argument('--use_pca', type=bool, default=False)
        parser.add_argument("--pc", type=int, default=30)

        # 路径和名称
        parser.add_argument('--data_set_path', type=str, default='./data')
        parser.add_argument('--work_dir', type=str, default='/spaspemamba__code/output')
        parser.add_argument('--net_name', type=str, default='MambaHSI')
        parser.add_argument('--exp_name', type=str, default='test1_8')

        # 模型
        # parser.add_argument('--SSAS', type=List, default=['b c t h w', 'b h w c t'])
        # parser.add_argument('--channel', type=int, default=128)
        # parser.add_argument('--num_layer', type=int, default=2)
        parser.add_argument('--model_index', type=float, default=model_index)
        # 0: 2,128-128-256
        # 1: 4,128-128-256-256-512
        # 2: 4,64-64-128-128-128
        # 3: 6,64-64-128-128-256-256-512
        # 4: 6,32-32-64-64-128-128-256

        # 超参数
        parser.add_argument('--lr', type=float, default=lr)
        parser.add_argument('--weight_decay', type=float, default=weight_decay)
        # parser.add_argument('--lr', type=List, default=[0.0005, 0.0004, 0.0006, 0.0007])
        parser.add_argument('--batch_size', type=int, default=batch_size)
        parser.add_argument('--batch_test_size', type=int, default=32)
        parser.add_argument('--max_epoch', type=int, default=500)
        parser.add_argument('--patience', type=int, default=120)

        # 其他
        parser.add_argument('--record_computecost', type=bool, default=False)  # 是否记录计算成本(如FLOPs、参数量等)
        parser.add_argument('--is_val', type=bool, default=False)  # 是否在测试时使用验证集保存的最佳模型

        args = parser.parse_args()
        return args

    # 传回参数
    args = get_parser(patch_size, lr, batch_size, weight_decay, model_index)

    # 设置种子列表
    seed_list = [1, 11, 111, 1111, 11111, 111111]

    # 采样情况
    num_list = [args.train_samples, args.val_samples]

    # 设置设备
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

    # 选择数据集
    data_set_name_list = ['UP', 'HanChuan', 'HongHu', 'Houston']
    data_name = data_set_name_list[args.dataset_index]

    # 保存路径
    concrete = f'patch_size:{patch_size}_lr:{lr}_batch_size:{batch_size}'
    save_folder = os.path.join(args.work_dir, args.net_name, data_name, args.exp_name, str(args.model_index), concrete)

    if not os.path.exists(save_folder):
        os.makedirs(save_folder)
        print("makedirs {}".format(save_folder))
    # 设置日志系统
    save_log_path = os.path.join(save_folder, 'train_tr{}_val{}.log'.format(num_list[0], num_list[1]))
    logger = setup_logger(name='{}'.format(data_name), logfile=save_log_path)  # 初始化日志记录器

    logger.info(patch_size, lr, batch_size)

    # 加载数据集
    image, gt, labels = load_mat_hsi(data_name, args.data_set_path)
    X = torch.tensor(image).unsqueeze(0).permute(0, 3, 1, 2)

    # 获取数据维度信息
    height, width, time = X.shape[2], X.shape[3], X.shape[1]

    # 计算类别数量（通过统计唯一标签值）
    class_count = len(labels)

    # 初始化结果存储列表
    OA_ALL = []
    AA_ALL = []
    KPP_ALL = []
    EACH_ACC_ALL = []
    Train_Time_ALL = []
    Test_Time_ALL = []

    # 对每个随机种子进行实验
    for exp_idx, curr_seed in enumerate(seed_list):

        # 设置日志系统
        writer = SummaryWriter(log_dir=f"/{save_folder}/RUNS/{curr_seed}", filename_suffix="exp1")

        # 设置随机种子
        setup_seed(curr_seed)
        # 创建单次实验的名称和文件夹
        single_experiment_name = 'run{}_seed{}'.format(str(exp_idx), str(curr_seed))
        save_single_experiment_folder = os.path.join(save_folder, single_experiment_name)

        if not os.path.exists(save_single_experiment_folder):
            os.mkdir(save_single_experiment_folder)

        # 创建可视化结果保存文件夹
        save_vis_folder = os.path.join(save_single_experiment_folder, 'vis')
        if not os.path.exists(save_vis_folder):
            os.makedirs(save_vis_folder)
            print("makedirs {}".format(save_vis_folder))

        # 设置各种保存路径
        save_weight_path = os.path.join(save_single_experiment_folder,
                                        "best_tr{}_val{}.pth".format(num_list[0], num_list[1]))
        results_save_path = os.path.join(save_single_experiment_folder,
                                         'result_tr{}_val{}.txt'.format(num_list[0], num_list[1]))
        predict_save_path = os.path.join(save_single_experiment_folder,
                                         'pred_vis_tr{}_val{}.png'.format(num_list[0], num_list[1]))
        gt_save_path = os.path.join(save_single_experiment_folder,
                                    'gt_vis_tr{}_val{}.png'.format(num_list[0], num_list[1]))

        # 进行数据采样，获取训练、验证和测试集的索引
        train_gt, val_gt, test_gt = sample_gt_by_class(gt, args.train_samples, args.val_samples, curr_seed)
        # train_gt, test_gt = sample_gt_by_class(gt, args.train_samples, args.val_samples, curr_seed)

        train_set = HSIDataset(image, train_gt, patch_size=args.patch_train_size, data_aug=True, use_pca=args.use_pca,
                               pc=args.pc)
        val_set = HSIDataset(image, val_gt, patch_size=args.patch_train_size, data_aug=True, use_pca=args.use_pca,
                             pc=args.pc)

        train_loader = torch.utils.data.DataLoader(train_set, args.batch_size, drop_last=False, shuffle=True)
        val_loader = torch.utils.data.DataLoader(val_set, 16, drop_last=False, shuffle=False)

        # 打印各类采样数量
        if exp_idx == 0:
            split_info_print(train_gt, test_gt, labels)

        train_gt = torch.from_numpy(train_gt).type(torch.FloatTensor).to(device)
        test_gt = torch.from_numpy(test_gt).type(torch.FloatTensor).to(device)

        # 模型
        if args.model_index == 2.1:
            SSAS = ['(b h w) c t', 'spiral']
            channel = 64
            net = SpaSpeMamba(input_channels=channel, n_stages=2, input_size=[time, args.patch_train_size, args.patch_train_size],
                              strides=[[1, 1, 1], [1, 2, 2]],
                              num_classes=class_count, features_per_stage=[channel, channel*2], n_conv_per_stage=[2, 2],
                              n_conv_per_stage_decoder=[2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )

        elif args.model_index == 4.1:
            SSAS = ['(b h w) c t', 'spiral', '(b h w) c t', 'spiral']
            channel = 128
            net = SpaSpeMamba(input_channels=channel, n_stages=4,
                              input_size=[time, args.patch_train_size, args.patch_train_size],
                              strides=[[1,1,1],[1,2,2],[1,1,1],[1,2,2]],
                              num_classes=class_count, features_per_stage=[channel, channel * 2, channel * 2, channel * 4],
                              n_conv_per_stage=[2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2],
                              kernel_sizes=[[1,3,3],[3,3,3],[3,3,3],[3,3,3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif args.model_index == 4.2:
            SSAS = ['(b h w) c t', 'spiral', '(b h w) c t', 'spiral']
            channel = 128
            net = SpaSpeMamba(input_channels=channel, n_stages=4,
                              input_size=[time, args.patch_train_size, args.patch_train_size],
                              strides=[[1,1,1],[1,2,2],[1,1,1],[1,2,2]],
                              num_classes=class_count, features_per_stage=[channel, channel * 2, channel * 2, channel * 4],
                              n_conv_per_stage=[2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2],
                              kernel_sizes=[[1,3,3],[3,3,3],[3,3,3],[3,3,3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif args.model_index == 4.3:
            SSAS = ['(b t) c h w', 'spiral', '(b t) c h w', 'spiral']
            channel = 64
            net = SpaSpeMamba(input_channels=channel, n_stages=4,
                              input_size=[time, args.patch_train_size, args.patch_train_size],
                              strides=[[1,1,1],[1,2,2],[1,1,1],[1,2,2]],
                              num_classes=class_count, features_per_stage=[channel, channel * 2, channel * 2, channel * 4],
                              n_conv_per_stage=[2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2],
                              kernel_sizes=[[1,3,3],[3,3,3],[3,3,3],[3,3,3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif args.model_index == 2:
            SSAS = ['(b h w) c t', 'spiral', '(b h w) c t', 'spiral']
            channel = 64
            net = SpaSpeMamba(input_channels=channel, n_stages=4,
                              input_size=[time, args.patch_train_size, args.patch_train_size],
                              strides=[[1,1,1],[1,2,2],[1,1,1],[1,2,2]],
                              num_classes=class_count, features_per_stage=[channel, channel * 2, channel * 2, channel * 4],
                              n_conv_per_stage=[2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2],
                              kernel_sizes=[[1,3,3],[3,3,3],[3,3,3],[3,3,3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif args.model_index == 6.1:
            SSAS = ['(b h w) c t', '(b t) c h w', 'spiral', '(b w h) c t', '(b t) c w h', 'spiral']
            channel = 64
            net = SpaSpeMamba(input_channels=channel, n_stages=6,
                              input_size=[103, 64, 64],
                              strides=[[1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2]],
                              num_classes=class_count,
                              features_per_stage=[channel, channel * 2, channel * 2, channel * 4, channel * 4,
                                                  channel * 8],
                              n_conv_per_stage=[2, 2, 2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2, 2, 2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif args.model_index == 6.2:
            SSAS = ['(b t) c h w', '(b h w) c t', 'spiral', '(b t) c w h', '(b w h) c t', 'spiral']
            channel = 64
            net = SpaSpeMamba(input_channels=channel, n_stages=6,
                              input_size=[103, 64, 64],
                              strides=[[1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2]],
                              num_classes=class_count,
                              features_per_stage=[channel, channel * 2, channel * 2, channel * 4, channel * 4,
                                                  channel * 8],
                              n_conv_per_stage=[2, 2, 2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2, 2, 2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif args.model_index == 6.3:
            SSAS = ['(b w h) c t', '(b t) c w h', 'spiral', '(b h w) c t', '(b t) c h w', 'spiral']
            channel = 64
            net = SpaSpeMamba(input_channels=channel, n_stages=6,
                              input_size=[103, 64, 64],
                              strides=[[1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2]],
                              num_classes=class_count,
                              features_per_stage=[channel, channel * 2, channel * 2, channel * 4, channel * 4,
                                                  channel * 8],
                              n_conv_per_stage=[2, 2, 2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2, 2, 2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif args.model_index == 6.4:
            SSAS = ['(b t) c w h', '(b w h) c t', 'spiral', '(b t) c h w', '(b h w) c t', 'spiral']
            channel = 64
            net = SpaSpeMamba(input_channels=channel, n_stages=6,
                              input_size=[103, 64, 64],
                              strides=[[1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2]],
                              num_classes=class_count,
                              features_per_stage=[channel, channel * 2, channel * 2, channel * 4, channel * 4,
                                                  channel * 8],
                              n_conv_per_stage=[2, 2, 2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2, 2, 2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif args.model_index == 6.5:
            SSAS = ['spiral', '(b h w) c t', '(b t) c h w', 'spiral', '(b w h) c t', '(b t) c w h']
            channel = 64
            net = SpaSpeMamba(input_channels=channel, n_stages=6,
                              input_size=[103, 64, 64],
                              strides=[[1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2]],
                              num_classes=class_count,
                              features_per_stage=[channel, channel * 2, channel * 2, channel * 4, channel * 4,
                                                  channel * 8],
                              n_conv_per_stage=[2, 2, 2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2, 2, 2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif args.model_index == 6.6:
            SSAS = ['spiral', '(b t) c h w', '(b h w) c t', 'spiral', '(b t) c w h', '(b w h) c t']
            channel = 64
            net = SpaSpeMamba(input_channels=channel, n_stages=6,
                              input_size=[103, 64, 64],
                              strides=[[1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2]],
                              num_classes=class_count,
                              features_per_stage=[channel, channel * 2, channel * 2, channel * 4, channel * 4,
                                                  channel * 8],
                              n_conv_per_stage=[2, 2, 2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2, 2, 2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif args.model_index == 6.7:
            SSAS = ['b c h w t', '(b t) c h w', 'spiral', 'b c w h t', '(b t) c w h', 'spiral']
            channel = 64
            net = SpaSpeMamba(input_channels=channel, n_stages=6,
                              input_size=[103, 64, 64],
                              strides=[[1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2]],
                              num_classes=class_count,
                              features_per_stage=[channel, channel * 2, channel * 2, channel * 4, channel * 4,
                                                  channel * 8],
                              n_conv_per_stage=[2, 2, 2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2, 2, 2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif args.model_index == 6.8:
            SSAS = ['(b t) c h w', 'b c h w t', 'spiral', '(b t) c w h', 'b c w h t', 'spiral']
            channel = 64
            net = SpaSpeMamba(input_channels=channel, n_stages=6,
                              input_size=[103, 64, 64],
                              strides=[[1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2]],
                              num_classes=class_count,
                              features_per_stage=[channel, channel * 2, channel * 2, channel * 4, channel * 4,
                                                  channel * 8],
                              n_conv_per_stage=[2, 2, 2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2, 2, 2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif args.model_index == 6.9:
            SSAS = ['b c h w t', 'spiral', '(b t) c h w', 'b c w h t', 'spiral', '(b t) c w h']
            channel = 64
            net = SpaSpeMamba(input_channels=channel, n_stages=6,
                              input_size=[103, 64, 64],
                              strides=[[1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2]],
                              num_classes=class_count,
                              features_per_stage=[channel, channel * 2, channel * 2, channel * 4, channel * 4,
                                                  channel * 8],
                              n_conv_per_stage=[2, 2, 2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2, 2, 2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif args.model_index == 6.10:
            SSAS = ['(b t) c h w', 'spiral', 'b c h w t', '(b t) c w h', 'spiral', 'b c w h t']
            channel = 64
            net = SpaSpeMamba(input_channels=channel, n_stages=6,
                              input_size=[103, 64, 64],
                              strides=[[1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2]],
                              num_classes=class_count,
                              features_per_stage=[channel, channel * 2, channel * 2, channel * 4, channel * 4,
                                                  channel * 8],
                              n_conv_per_stage=[2, 2, 2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2, 2, 2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        else:
            print("模型层数设置错误，请修改！！！")
            break

        net.to(device)

        logger.info(net)

        # ===================== 优化器（Adam） ======================
        # optimizer = torch.optim.Adam(
        #     net.parameters(),
        #     lr=args.lr,
        #     weight_decay=0
        # )
        optimizer = torch.optim.AdamW(
            net.parameters(),
            lr=args.lr,
            weight_decay=args.weight_decay,
            betas=(0.9, 0.999)
        )

        # ===================== 阶梯式下降调度器 ======================
        # scheduler = torch.optim.lr_scheduler.MultiStepLR(
        #     optimizer,
        #     milestones=[75, 110],  # 在第 100 和 150 轮衰减
        #     gamma=0.3  # 乘以 0.3
        # )
        scheduler = None
        # scheduler = get_warmup_cosine_schedule(
        #     optimizer,
        #     warmup_epochs=10,
        #     total_epochs=100,
        #     warmup_start_lr=0.0,
        #     base_lr=args.lr,
        #     eta_min=1e-4
        # )

        # ===================== 损失函数 ======================
        loss_func = torch.nn.CrossEntropyLoss()

        '''
        开始训练
        
        '''
        train(net, optimizer, loss_func, train_loader, val_loader, args.max_epoch, save_weight_path, device, scheduler, logger, writer, args.patience)

        '''
        开始测试

        '''
        if args.use_pca == True:
            original_shape = image.shape
            reshaped_image = image.reshape(-1, original_shape[2])
            pca = PCA(n_components=args.pc)
            pca_result = pca.fit_transform(reshaped_image)
            image = pca_result.reshape(original_shape[0], original_shape[1], args.pc)

        probabilities = test(net, class_count, args.model_index, save_weight_path, image, args.patch_test_size, class_count, device, time, args.batch_test_size, args.is_val)

        prediction = np.argmax(probabilities, axis=-1)
        prediction = torch.from_numpy(prediction)

        '''
        开始评估

        '''
        # 初始化评估器
        test_evaluator = Evaluator(num_class=class_count)

        final_pred = prediction.unsqueeze(0)
        # 调整输出尺寸以匹配标签
        # y_test = test_gt.unsqueeze(0)  # 增加批次维度
        Y_test_np = test_gt.cpu().numpy()
        Y_test_255 = np.where(Y_test_np == -1, 255, Y_test_np)  # 将忽略标签转为255

        # 添加批次数据到评估器
        test_evaluator.add_batch(np.expand_dims(Y_test_255, axis=0), final_pred.cpu().numpy().astype(np.int64))

        # 计算各种评估指标
        OA_test = test_evaluator.Pixel_Accuracy()  # 总体精度
        mIOU_test, IOU_test = test_evaluator.Mean_Intersection_over_Union()  # 交并比
        mAcc_test, Acc_test = test_evaluator.Pixel_Accuracy_Class()  # 类别精度
        Kappa_test = test_evaluator.Kappa()  # Kappa系数

        # 记录测试结果
        logger.info(
            'Test {}|OA:{}|MACC:{}|Kappa:{}|MIOU:{}|IOU:{}|ACC:{}'.format(args.max_epoch, OA_test, mAcc_test, Kappa_test,
                                                                          mIOU_test, IOU_test,
                                                                          Acc_test))
        gt_1 = gt + 1
        vis_a_image(gt_1, final_pred.cpu().numpy(), predict_save_path, gt_save_path)

        # 打开结果文件并追加本次实验结果
        # Output infors
        f = open(results_save_path, 'a+')
        str_results = '\n======================' \
                      + " exp_idx=" + str(exp_idx) \
                      + " seed=" + str(curr_seed) \
                      + " learning rate=" + str(args.lr) \
                      + " epochs=" + str(args.max_epoch) \
                      + " train ratio=" + str(args.train_samples) \
                      + " val ratio=" + str(args.val_samples) \
                      + " ======================" \
                      + "\nOA=" + str(OA_test) \
                      + "\nAA=" + str(mAcc_test) \
                      + '\nkpp=' + str(Kappa_test) \
                      + '\nmIOU_test:' + str(mIOU_test) \
                      + "\nIOU_test:" + str(IOU_test) \
                      + "\nAcc_test:" + str(Acc_test) + "\n"

        logger.info(str_results)  # 记录到日志
        f.write(str_results)  # 写入文件
        f.close()  # 关闭文件

        # 将本次实验结果添加到总列表中
        OA_ALL.append(OA_test)  # 总体精度
        AA_ALL.append(mAcc_test)  # 平均精度
        KPP_ALL.append(Kappa_test)  # Kappa系数
        EACH_ACC_ALL.append(Acc_test)  # 各类别精度

        torch.cuda.empty_cache()  # 清理GPU缓存

        # 关闭日志系统
        writer.close()

    # 将列表转换为numpy数组以便计算统计量
    OA_ALL = np.array(OA_ALL)
    AA_ALL = np.array(AA_ALL)
    KPP_ALL = np.array(KPP_ALL)
    EACH_ACC_ALL = np.array(EACH_ACC_ALL)
    # Train_Time_ALL = np.array(Train_Time_ALL)
    # Test_Time_ALL = np.array(Test_Time_ALL)

    # 设置numpy输出精度
    np.set_printoptions(precision=4)

    # 记录多次实验的平均结果和标准差
    logger.info("\n====================Mean result of {} times runs =========================".format(len(seed_list)))
    logger.info('List of OA: %s', list(OA_ALL))
    logger.info('List of AA: %s', list(AA_ALL))
    logger.info('List of KPP: %s', list(KPP_ALL))
    # 计算并记录平均值和标准差
    logger.info('OA= %f %s %f', round(np.mean(OA_ALL) * 100, 2), '+-', round(np.std(OA_ALL) * 100, 2))
    logger.info('AA= %f %s %f', round(np.mean(AA_ALL) * 100, 2), '+-', round(np.std(AA_ALL) * 100, 2))
    logger.info('Kpp= %f %s %f', round(np.mean(KPP_ALL) * 100, 2), '+-', round(np.std(KPP_ALL) * 100, 2))
    logger.info('Acc per class= %s %s %s', np.round(np.mean(EACH_ACC_ALL, 0) * 100, decimals=2), '+-',
                np.round(np.std(EACH_ACC_ALL, 0) * 100, decimals=2))

    # logger.info("Average training time= %f %s %f", round(np.mean(Train_Time_ALL), 2), '+-', round(np.std(Train_Time_ALL), 3))
    # logger.info("Average testing time= %f %s %f", round(np.mean(Test_Time_ALL) * 1000, 2), '+-',
    #       round(np.std(Test_Time_ALL) * 1000, 3))

    # Output infors
    # 创建平均结果文件
    mean_result_path = os.path.join(save_folder, 'mean_result.txt')
    f = open(mean_result_path, 'w')
    # str_results = '\n\n***************Mean result of ' + str(len(seed_list)) + 'times runs ********************' \
    #               + '\nList of OA:' + str(list(OA_ALL)) \
    #               + '\nList of AA:' + str(list(AA_ALL)) \
    #               + '\nList of KPP:' + str(list(KPP_ALL)) \
    #               + '\nOA=' + str(round(np.mean(OA_ALL) * 100, 2)) + '+-' + str(round(np.std(OA_ALL) * 100, 2)) \
    #               + '\nAA=' + str(round(np.mean(AA_ALL) * 100, 2)) + '+-' + str(round(np.std(AA_ALL) * 100, 2)) \
    #               + '\nKpp=' + str(round(np.mean(KPP_ALL) * 100, 2)) + '+-' + str(
    #     round(np.std(KPP_ALL) * 100, 2)) \
    #               + '\nAcc per class=\n' + str(np.round(np.mean(EACH_ACC_ALL, 0) * 100, 2)) + '+-' + str(
    #     np.round(np.std(EACH_ACC_ALL, 0) * 100, 2)) \
    #               + "\nAverage training time=" + str(
    #     np.round(np.mean(Train_Time_ALL), decimals=2)) + '+-' + str(
    #     np.round(np.std(Train_Time_ALL), decimals=3)) \
    #               + "\nAverage testing time=" + str(
    #     np.round(np.mean(Test_Time_ALL) * 1000, decimals=2)) + '+-' + str(
    #     np.round(np.std(Test_Time_ALL) * 100, decimals=3))
    str_results = '\n\n***************Mean result of ' + str(len(seed_list)) + 'times runs ********************' \
                  + '\nList of OA:' + str(list(OA_ALL)) \
                  + '\nList of AA:' + str(list(AA_ALL)) \
                  + '\nList of KPP:' + str(list(KPP_ALL)) \
                  + '\nOA=' + str(round(np.mean(OA_ALL) * 100, 2)) + '+-' + str(round(np.std(OA_ALL) * 100, 2)) \
                  + '\nAA=' + str(round(np.mean(AA_ALL) * 100, 2)) + '+-' + str(round(np.std(AA_ALL) * 100, 2)) \
                  + '\nKpp=' + str(round(np.mean(KPP_ALL) * 100, 2)) + '+-' + str(
        round(np.std(KPP_ALL) * 100, 2)) \
                  + '\nAcc per class=\n' + str(np.round(np.mean(EACH_ACC_ALL, 0) * 100, 2)) + '+-' + str(
        np.round(np.std(EACH_ACC_ALL, 0) * 100, 2))

    f.write(str_results)
    f.close()

    del net

    return np.mean(KPP_ALL)


if __name__ == "__main__":
    lr = 0.0004
    paych_size = 9
    batch_size = 32
    weight_decay = 0.00001
    model_index = 6.8
    result = train_and_eval(paych_size, lr, batch_size, weight_decay, model_index)

    print(result)





