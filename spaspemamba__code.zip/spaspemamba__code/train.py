import os
import numpy as np
from tqdm import tqdm
import torch
from utils.DSF.utils import grouper, sliding_window, count_sliding_window
import matplotlib.pyplot as plt
from model.SpaSpeMamba_1 import SpaSpeMamba

def train(network, optimizer, criterion, train_loader, val_loader, epochs, saving_path, device, scheduler, logger, writer, patience):

    best_acc = -0.1
    losses = []
    patience_counter = 0
    # X = X.to(device)
    for e in tqdm(range(1, epochs+1), desc=""):
        network.train()

        for batch_idx, (images, targets) in enumerate(tqdm(train_loader)):
            images, targets = images.to(device), targets.to(device)
            optimizer.zero_grad()
            # outputs = network(images,X)
            outputs = network(images)
            loss = criterion(outputs, targets)
            # loss.backward(retain_graph=True)
            loss.backward()
            # torch.nn.utils.clip_grad_norm_(network.parameters(), max_norm=5)
            optimizer.step()
            losses.append(loss.item())

        mean_losses = np.mean(losses)
        train_info = "train at epoch {}/{}, loss={:.6f}"
        train_info = train_info.format(e, epochs,  mean_losses)
        logger.info(train_info)
        writer.add_scalar("train_loss", mean_losses, global_step=e)
        losses = []

        # 获取当前学习率和优化次数
        current_lr = optimizer.param_groups[0]['lr']
        writer.add_scalar("current_lr", current_lr, global_step=e)
        # 使用调度器，对学习率进行更新
        if scheduler is not None:
            scheduler.step()

        if val_loader != None:
            val_acc, val_loss = validation(network, criterion, val_loader, device)
            writer.add_scalar("val_acc", val_acc, global_step=e)
            writer.add_scalar("val_loss", val_loss, global_step=e)
            # if scheduler is not None:
            #     scheduler.step()

            # 早停机制 - 使用测试损失
            is_best = val_acc >= best_acc
            best_acc = max(val_acc, best_acc)
            if is_best:
                patience_counter = 0
                # 保存最佳模型
                save_checkpoint(network, is_best, saving_path, logger, epoch=e, acc=best_acc)
                print(f"√ 保存新的最佳模型，验证准确率：{val_acc:.6f}")
                logger.info(f"√ 保存新的最佳模型，验证准确率：{val_acc:.6f}")
            else:
                patience_counter += 1
                save_checkpoint(network, is_best, saving_path, logger, epoch=e, acc=best_acc)
                print(f"× 测试准确率未改善，当前: {val_acc:.6f}, 最佳: {best_acc:.6f}, 耐心计数: {patience_counter}/{patience}")
                logger.info(f"× 测试准确率未改善，当前: {val_acc:.6f}, 最佳: {best_acc:.6f}, 耐心计数: {patience_counter}/{patience}")

            print(f"Epoch {e + 1}/{epochs}, 训练损失: {mean_losses:.6f}, 测试损失: {val_loss:.6f}")

            if patience_counter >= patience:
                print(f"早停！测试准确率已经连续 {patience} 个epoch没有改善。")
                break


def train_1(network, optimizer, criterion, train_loader, val_loader, epoch, saving_path, device, scheduler=None):

    best_acc = -0.1
    losses = []
    # X = X.to(device)
    for e in tqdm(range(1, epoch + 1), desc=""):
        network.train()
        for batch_idx, (images, targets) in enumerate(train_loader):
            images = images.squeeze(1)
            images, targets = images.to(device), targets.to(device)
            optimizer.zero_grad()
            # outputs = network(images,X)
            outputs = network(images)
            loss = criterion(outputs, targets)
            loss.backward(retain_graph=True)
            optimizer.step()
            losses.append(loss.item())
        if e % 10 == 0 or e == 1:
            mean_losses = np.mean(losses)
            train_info = "train at epoch {}/{}, loss={:.6f}"
            train_info = train_info.format(e, epoch, mean_losses)
            tqdm.write(train_info)
            losses = []
        else:
            losses = []
        # val_acc = validation(network, val_loader, device)
        #
        # if scheduler is not None:
        #     scheduler.step()
        #
        # is_best = val_acc >= best_acc
        # best_acc = max(val_acc, best_acc)
        # save_checkpoint(network, is_best, saving_path, epoch=e, acc=best_acc)

def validation(network, criterion, val_loader, device):
    num_correct = 0.
    total_num = 0.
    losses = []
    network.eval()
    for batch_idx, (images, targets) in enumerate(tqdm(val_loader)):
        images, targets = images.to(device), targets.to(device)
        outputs = network(images)
        val_loss = criterion(outputs, targets)
        losses.append(val_loss.item())
        _, outputs = torch.max(outputs, dim=1) 
        for output, target in zip(outputs, targets):
            num_correct = num_correct + (output.item() == target.item())
            total_num = total_num + 1
    overall_acc = num_correct / total_num
    overall_loss = np.mean(losses)
    return overall_acc, overall_loss


def test(network, class_count, model_index, model_dir, image, patch_size, n_classes, device, time, batch_test_size, is_val, fourth_dimension=True):
# def test(network, image, patch_size, n_classes, device, batch_test_size):

    if is_val:
        # 模型
        if model_index == 0:
            SSAS = ['b c t h w', 'b h w c t']
            channel = 128
            net = SpaSpeMamba(input_channels=channel, n_stages=2,
                              input_size=[time, patch_size, patch_size],
                              strides=[[1, 1, 1], [1, 2, 2]],
                              num_classes=class_count, features_per_stage=[channel, channel * 2],
                              n_conv_per_stage=[2, 2],
                              n_conv_per_stage_decoder=[2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )

        elif model_index == 1:
            SSAS = ['b c t h w', 'b h w c t', 'b c t h w', 'b h w c t']
            channel = 128
            net = SpaSpeMamba(input_channels=channel, n_stages=4,
                              input_size=[time, patch_size, patch_size],
                              strides=[[1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2]],
                              num_classes=class_count,
                              features_per_stage=[channel, channel * 2, channel * 2, channel * 4],
                              n_conv_per_stage=[2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif model_index == 2:
            SSAS = ['b c t h w', 'b h w c t', 'b c t h w', 'b h w c t']
            channel = 64
            net = SpaSpeMamba(input_channels=channel, n_stages=4,
                              input_size=[time, patch_size, patch_size],
                              strides=[[1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2]],
                              num_classes=class_count,
                              features_per_stage=[channel, channel * 2, channel * 2, channel * 4],
                              n_conv_per_stage=[2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif model_index == 3:
            SSAS = ['b c t h w', 'b h w c t', 'b c t h w', 'b h w c t', 'b c t h w', 'b h w c t']
            channel = 64
            net = SpaSpeMamba(input_channels=channel, n_stages=6,
                              input_size=[103, 64, 64],
                              strides=[[1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2]],
                              num_classes=class_count,
                              features_per_stage=[channel, channel * 2, channel * 2, channel * 4, channel * 4,
                                                  channel * 8],
                              n_conv_per_stage=[2, 2, 2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2, 2, 2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        elif model_index == 4:
            SSAS = ['b c t h w', 'b h w c t', 'b c t h w', 'b h w c t', 'b c t h w', 'b h w c t']
            channel = 32
            net = SpaSpeMamba(input_channels=channel, n_stages=6,
                              input_size=[103, 64, 64],
                              strides=[[1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2], [1, 1, 1], [1, 2, 2]],
                              num_classes=class_count,
                              features_per_stage=[channel, channel * 2, channel * 2, channel * 4, channel * 4,
                                                  channel * 8],
                              n_conv_per_stage=[2, 2, 2, 2, 2, 2],
                              n_conv_per_stage_decoder=[2, 2, 2, 2, 2],
                              kernel_sizes=[[1, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3]],
                              SSAS=SSAS,
                              hidden_dim=time,
                              )
        else:
            print("模型层数设置错误，请修改！！！")



        network.to(device)
        network.load_state_dict(torch.load(model_dir + "/model_best.pth"))

    network.eval()

    patch_size = patch_size
    batch_size = batch_test_size
    window_size = (patch_size, patch_size)
    image_w, image_h = image.shape[:2]
    pad_size = patch_size // 2
    # X = X.to(device)

    # pad the image
    image = np.pad(image, ((pad_size, pad_size), (pad_size, pad_size), (0, 0)), mode='reflect')

    probs = np.zeros(image.shape[:2] + (n_classes, ))

    iterations = count_sliding_window(image, window_size=window_size) // batch_size
    for batch in tqdm(grouper(batch_size, sliding_window(image, window_size=window_size)),
                      total=iterations,
                      desc="inference on the HSI"):
        with torch.no_grad():
            data = [b[0] for b in batch]
            data = np.copy(data)
            data = data.transpose((0, 3, 1, 2))
            data = torch.from_numpy(data)
            if fourth_dimension:
                data = data.unsqueeze(1)

            indices = [b[1:] for b in batch]
            data = data.to(device)
            # output = network(data,X)
            output = network(data)
            if isinstance(output, tuple):
                output = output[0]
            output = output.to('cpu').numpy()

            for (x, y, w, h), out in zip(indices, output):
                probs[x + w // 2, y + h // 2] += out
    return probs[pad_size:image_w + pad_size, pad_size:image_h + pad_size, :]

def test_1(network, model_dir, image, patch_size, n_classes, device):
    # network.load_state_dict(torch.load(model_dir + "/model_best.pth"))
    network.eval()

    patch_size = patch_size
    batch_size = 1024
    window_size = (patch_size, patch_size)
    image_w, image_h = image.shape[:2]
    pad_size = patch_size // 2
    # X = X.to(device)

    # pad the image
    image = np.pad(image, ((pad_size, pad_size), (pad_size, pad_size), (0, 0)), mode='reflect')

    probs = np.zeros(image.shape[:2] + (n_classes, ))

    iterations = count_sliding_window(image, window_size=window_size) // batch_size
    for batch in tqdm(grouper(batch_size, sliding_window(image, window_size=window_size)),
                      total=iterations,
                      desc="inference on the HSI"):
        with torch.no_grad():
            data = [b[0] for b in batch]
            data = np.copy(data)
            data = data.transpose((0, 3, 1, 2))
            data = torch.from_numpy(data)
            # data = data.unsqueeze(1)   # ss_mamba b,c,h,w

            indices = [b[1:] for b in batch]
            data = data.to(device)
            # output = network(data,X)
            output = network(data)
            if isinstance(output, tuple):
                output = output[0]
            output = output.to('cpu').numpy()

            for (x, y, w, h), out in zip(indices, output):
                probs[x + w // 2, y + h // 2] += out
    return probs[pad_size:image_w + pad_size, pad_size:image_h + pad_size, :]

def save_checkpoint(network, is_best, saving_path, logger, **kwargs):
    if not os.path.isdir(saving_path):
        os.makedirs(saving_path, exist_ok=True)

    if is_best:
        logger.info("epoch = {epoch}: best OA = {acc:.4f}".format(**kwargs))
        torch.save(network.state_dict(), os.path.join(saving_path, 'model_best.pth'))
    else:  # save the ckpt for each 10 epoch
        if kwargs['epoch'] % 10 == 0:
            torch.save(network.state_dict(), os.path.join(saving_path, 'model.pth'))


