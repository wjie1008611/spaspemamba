import math
import torch
from calflops import calculate_flops
from torch import nn
import numpy as np
from torch.nn.modules.conv import _ConvNd
from torch.nn.modules.dropout import _DropoutNd
from typing import Union, Type, List, Tuple
from dynamic_network_architectures.building_blocks.residual import BasicBlockD
from dynamic_network_architectures.building_blocks.helper import maybe_convert_scalar_to_list, get_matching_pool_op
from dynamic_network_architectures.building_blocks.helper import convert_conv_op_to_dim
from torch.cuda.amp import autocast
from einops import rearrange
from mamba_ssm import Mamba
# import sys
# import pprint
#

from model.utils.Continues_Scan_1 import spiral_scan_3d,rev_spiral_restore_3d
from model.utils.Continues_Scan import continues_scan,rev_continues_scan
from torch.nn import functional as F
from einops.layers.torch import Reduce

class UpsampleLayer(nn.Module):
    def __init__(
            self,
            conv_op,
            input_channels,
            output_channels,
            pool_op_kernel_size,
            mode='nearest'
    ):
        super().__init__()
        self.conv = conv_op(input_channels, output_channels, kernel_size=1)
        self.pool_op_kernel_size = pool_op_kernel_size
        self.mode = mode

    def forward(self, x):
        # x = F.interpolate(x, scale_factor=self.pool_op_kernel_size, mode=self.mode)

        if isinstance(self.pool_op_kernel_size, (list, tuple)):
            # x的形状是 (Batch, Channel, Depth, Height, Width)
            target_size = (
                int(x.shape[2] * self.pool_op_kernel_size[0]),  # Depth
                int(x.shape[3] * self.pool_op_kernel_size[1]),  # Height
                int(x.shape[4] * self.pool_op_kernel_size[2])  # Width
            )
            x = F.interpolate(x, size=target_size, mode=self.mode)
        else:
            x = F.interpolate(x, scale_factor=self.pool_op_kernel_size, mode=self.mode)

        x = self.conv(x)
        return x

class BasicResBlock(nn.Module):
    def __init__(
            self,
            conv_op,
            input_channels,
            output_channels,
            norm_op,
            norm_op_kwargs,
            kernel_size=3,
            padding=1,
            stride=1,
            use_1x1conv=False,
            nonlin=nn.LeakyReLU,
            nonlin_kwargs={'inplace': True}
    ):
        super().__init__()

        self.conv1 = conv_op(input_channels, output_channels, kernel_size, stride=stride, padding=padding)
        self.norm1 = norm_op(output_channels, **norm_op_kwargs)
        self.act1 = nonlin(**nonlin_kwargs)

        self.conv2 = conv_op(output_channels, output_channels, kernel_size, padding=padding)
        self.norm2 = norm_op(output_channels, **norm_op_kwargs)
        self.act2 = nonlin(**nonlin_kwargs)

        if use_1x1conv:
            self.conv3 = conv_op(input_channels, output_channels, kernel_size=1, stride=stride)
        else:
            self.conv3 = None

    def forward(self, x):
        y = self.conv1(x)
        y = self.act1(self.norm1(y))
        y = self.norm2(self.conv2(y))
        if self.conv3:
            x = self.conv3(x)
        y += x
        return self.act2(y)


class MambaLayer(nn.Module):
    def __init__(self, dim, d_state=16, d_conv=4, expand=2, channel_token=False, SSAS=None):
        super().__init__()
        print(f"MambaLayer: dim: {dim}")
        self.SSAS = SSAS
        self.dim = dim
        self.norm = nn.LayerNorm(dim)
        self.mamba = Mamba(
            d_model=dim,  # Model dimension d_model
            d_state=d_state,  # SSM state expansion factor
            d_conv=d_conv,  # Local convolution width
            expand=expand,  # Block expansion factor
            bimamba= True
        )
        self.channel_token = channel_token  ## whether to use channel as tokens

    def forward_patch_token(self, x, r=False):
        B, C, T, H, W = x.shape

        if self.SSAS == 'spiral':
            connect = True
            x = spiral_scan_3d(x)

        elif self.SSAS == 'b c h w t' or self.SSAS == 'b c w h t' or self.SSAS == 'b c t h w':
            connect = True
            x = rearrange(x, 'b c t h w -> ' + self.SSAS, b=B, c=C, t=T, h=H, w=W)
            x = continues_scan(x)

        else:
            connect = False
            x = rearrange(x, 'b c t h w -> ' + self.SSAS, b=B, c=C, t=T, h=H, w=W)

        # x = spiral_scan_3d(x, self.SSAS, connect)

        if not connect:
            if self.SSAS == '(b h w) c t' or self.SSAS == '(b w h) c t':
                d_model = H * W
            else:
                d_model = T
            n_tokens = x.shape[1:].numel()
            img_dims = x.shape[1:]
        else:
            B, d_model = x.shape[:2]
            n_tokens = x.shape[2:].numel()
            img_dims = x.shape[2:]

        x_flat = x.reshape(B, d_model, n_tokens).contiguous().transpose(-1, -2)
        x_norm = self.norm(x_flat)
        x_mamba = self.mamba(x_norm)
        # x_mamba_b = self.mamba_b(x_norm.flip(1)).flip(1)
        # x_mamba = x_mamba + x_mamba_b

        # if not connect:
        #     out = x_mamba.transpose(-1, -2).reshape(B * d_model, *img_dims)
        #     out = rearrange(out, self.SSAS + ' -> b c t h w', b=B, c=C, t=T, h=H, w=W)
        #
        # else:
        #     out = x_mamba.transpose(-1, -2).reshape(B, d_model, *img_dims)
        #     out = rev_spiral_restore_3d(out).contiguous()

        if self.SSAS == 'spiral':
            out = x_mamba.transpose(-1, -2).reshape(B, d_model, *img_dims)
            out = rev_spiral_restore_3d(out).contiguous()

        elif self.SSAS == 'b c h w t' or self.SSAS == 'b c w h t' or self.SSAS == 'b c t h w':
            out = x_mamba.transpose(-1, -2).reshape(B, d_model, *img_dims)
            out = rev_continues_scan(out).contiguous()
            out = rearrange(out, self.SSAS + ' -> b c t h w', b=B, c=C, t=T, h=H, w=W)

        else:
            out = x_mamba.transpose(-1, -2).reshape(B * d_model, *img_dims)
            out = rearrange(out, self.SSAS + ' -> b c t h w', b=B, c=C, t=T, h=H, w=W)

        return out

    def forward_channel_token(self, x, r=False):
        B, n_tokens = x.shape[:2]
        d_model = x.shape[2:].numel()
        assert d_model == self.dim, f"d_model: {d_model}, self.dim: {self.dim}"
        img_dims = x.shape[2:]
        x_flat = x.flatten(2)
        assert x_flat.shape[2] == d_model, f"x_flat.shape[2]: {x_flat.shape[2]}, d_model: {d_model}"
        x_norm = self.norm(x_flat)
        x_mamba = self.mamba(x_norm)
        out = x_mamba.reshape(B, n_tokens, *img_dims)

        return out

    @autocast(enabled=False)
    def forward(self, x, r=False):
        if x.dtype == torch.float16 or x.dtype == torch.bfloat16:
            x = x.type(torch.float32)

        if self.channel_token:
            out = self.forward_channel_token(x, r=r)
        else:
            out = self.forward_patch_token(x, r=r)

        return out


class ResidualMambaEncoder(nn.Module):
    def __init__(self,
                 input_size: Tuple[int, ...],
                 input_channels: int,
                 n_stages: int,
                 features_per_stage: Union[int, List[int], Tuple[int, ...]],
                 conv_op: Type[_ConvNd],
                 kernel_sizes: Union[int, List[int], Tuple[int, ...]],
                 strides: Union[int, List[int], Tuple[int, ...], Tuple[Tuple[int, ...], ...]],
                 n_blocks_per_stage: Union[int, List[int], Tuple[int, ...]],
                 conv_bias: bool = False,
                 norm_op: Union[None, Type[nn.Module]] = None,
                 norm_op_kwargs: dict = None,
                 nonlin: Union[None, Type[torch.nn.Module]] = None,
                 nonlin_kwargs: dict = None,
                 hidden_dim: int = 103,
                 return_skips: bool = False,
                 stem_channels: int = None,
                 pool_type: str = 'conv',
                 SSAS=None,
                 patch_size=9
                 ):
        super().__init__()
        self.SSAS = SSAS
        # if self.SSAS[0] == '(b t) c h w' or self.SSAS[1] == '(b t) c h w':
        #     self.W = [103, 103, 103, 103, 103, 103]
        # else:
        #     self.W = [81, 25, 25, 9, 9, 4]
        if self.SSAS == ['(b h w) c t', '(b t) c h w', 'spiral', '(b w h) c t', '(b t) c w h', 'spiral']:
            if patch_size==7:
                self.W = [49, hidden_dim, 16, 4, hidden_dim, 1]
            elif patch_size==9:
                self.W = [81, hidden_dim, 25, 9, hidden_dim, 4]
            elif patch_size==11:
                self.W = [121, hidden_dim, 36, 9, hidden_dim, 4]
            elif patch_size==13:
                self.W = [169, hidden_dim, 49, 16, hidden_dim, 4]
        elif self.SSAS == ['(b t) c h w', '(b h w) c t', 'spiral', '(b t) c w h', '(b w h) c t', 'spiral']:
            if patch_size == 7:
                self.W = [hidden_dim, 16, 16, hidden_dim, 4, 1]
            elif patch_size == 9:
                self.W = [hidden_dim, 25, 25, hidden_dim, 9, 4]
            elif patch_size == 11:
                self.W = [hidden_dim, 36, 36, hidden_dim, 9, 4]
            elif patch_size == 13:
                self.W = [hidden_dim, 49, 49, hidden_dim, 16, 4]
        elif self.SSAS == ['(b w h) c t', '(b t) c w h', 'spiral', '(b h w) c t', '(b t) c h w', 'spiral']:
            if patch_size == 7:
                self.W = [49, hidden_dim, 16, 4, hidden_dim, 1]
            elif patch_size == 9:
                self.W = [81, hidden_dim, 25, 9, hidden_dim, 4]
            elif patch_size == 11:
                self.W = [121, hidden_dim, 36, 9, hidden_dim, 4]
            elif patch_size == 13:
                self.W = [169, hidden_dim, 49, 16, hidden_dim, 4]
        elif self.SSAS == ['(b t) c w h', '(b w h) c t', 'spiral', '(b t) c h w', '(b h w) c t', 'spiral']:
            if patch_size == 7:
                self.W = [hidden_dim, 16, 16, hidden_dim, 4, 1]
            elif patch_size == 9:
                self.W = [hidden_dim, 25, 25, hidden_dim, 9, 4]
            elif patch_size == 11:
                self.W = [hidden_dim, 36, 36, hidden_dim, 9, 4]
            elif patch_size == 13:
                self.W = [hidden_dim, 49, 49, hidden_dim, 16, 4]
        elif self.SSAS == ['spiral', '(b h w) c t', '(b t) c h w', 'spiral', '(b w h) c t', '(b t) c w h']:
            if patch_size == 7:
                self.W = [49, 16, hidden_dim, 4, 4, hidden_dim]
            elif patch_size == 9:
                self.W = [81, 25, hidden_dim, 9, 9, hidden_dim]
            elif patch_size == 11:
                self.W = [121, 36, hidden_dim, 9, 9, hidden_dim]
            elif patch_size == 13:
                self.W = [169, 49, hidden_dim, 16, 16, hidden_dim]
        elif self.SSAS == ['spiral', '(b t) c h w', '(b h w) c t', 'spiral', '(b t) c w h', '(b w h) c t']:
            if patch_size == 7:
                self.W = [49, hidden_dim, 16, 4, hidden_dim, 1]
            elif patch_size == 9:
                self.W = [81, hidden_dim, 25, 9, hidden_dim, 4]
            elif patch_size == 11:
                self.W = [121, hidden_dim, 36, 9, hidden_dim, 4]
            elif patch_size == 13:
                self.W = [169, hidden_dim, 49, 16, hidden_dim, 4]
        elif self.SSAS == ['b c h w t', '(b t) c h w', 'spiral', 'b c w h t', '(b t) c w h', 'spiral']:
            if patch_size == 7:
                self.W = [49, hidden_dim, 16, 4, hidden_dim, 1]
            elif patch_size == 9:
                self.W = [81, hidden_dim, 25, 9, hidden_dim, 4]
            elif patch_size == 11:
                self.W = [121, hidden_dim, 36, 9, hidden_dim, 4]
            elif patch_size == 13:
                self.W = [169, hidden_dim, 49, 16, hidden_dim, 4]
        elif self.SSAS == ['(b t) c h w', 'b c h w t', 'spiral', '(b t) c w h', 'b c w h t', 'spiral']:
            if patch_size==7:
                self.W = [hidden_dim, 16, 16, hidden_dim, 4, 1]
            elif patch_size==9:
                self.W = [hidden_dim, 25, 25, hidden_dim, 9, 4]
            elif patch_size==11:
                self.W = [hidden_dim, 36, 36, hidden_dim, 9, 4]
            elif patch_size==13:
                self.W = [hidden_dim, 49, 49, hidden_dim, 16, 4]

        elif self.SSAS == ['b c h w t', 'spiral', '(b t) c h w', 'b c w h t', 'spiral', '(b t) c w h']:
            if patch_size == 7:
                self.W = [49, 16, hidden_dim, 4, 4, hidden_dim]
            elif patch_size == 9:
                self.W = [81, 25, hidden_dim, 9, 9, hidden_dim]
            elif patch_size == 11:
                self.W = [121, 36, hidden_dim, 9, 9, hidden_dim]
            elif patch_size == 13:
                self.W = [169, 49, hidden_dim, 16, 16, hidden_dim]
        elif self.SSAS == ['(b t) c h w', 'spiral', 'b c h w t', '(b t) c w h', 'spiral', 'b c w h t']:
            if patch_size == 7:
                self.W = [hidden_dim, 16, 16, hidden_dim, 4, 1]
            elif patch_size == 9:
                self.W = [hidden_dim, 25, 25, hidden_dim, 9, 4]
            elif patch_size == 11:
                self.W = [hidden_dim, 36, 36, hidden_dim, 9, 4]
            elif patch_size == 13:
                self.W = [hidden_dim, 49, 49, hidden_dim, 16, 4]
        elif self.SSAS == ['b c t h w', 'b c t h w', 'b c t h w', 'b c t h w', 'b c t h w', 'b c t h w']:
            if patch_size == 7:
                self.W = [49, 16, 16, 4, 4, 1]
            elif patch_size == 9:
                self.W = [81, 25, 25, 9, 9, 4]
            elif patch_size == 11:
                self.W = [121, 36, 36, 9, 9, 4]
            elif patch_size == 13:
                self.W = [169, 49, 49, 16, 16, 4]


        if isinstance(kernel_sizes, int):
            kernel_sizes = [kernel_sizes] * n_stages
        if isinstance(features_per_stage, int):
            features_per_stage = [features_per_stage] * n_stages
        if isinstance(n_blocks_per_stage, int):
            n_blocks_per_stage = [n_blocks_per_stage] * n_stages
        if isinstance(strides, int):
            strides = [strides] * n_stages
        assert len(
            kernel_sizes) == n_stages, "kernel_sizes must have as many entries as we have resolution stages (n_stages)"
        assert len(
            n_blocks_per_stage) == n_stages, "n_conv_per_stage must have as many entries as we have resolution stages (n_stages)"
        assert len(
            features_per_stage) == n_stages, "features_per_stage must have as many entries as we have resolution stages (n_stages)"
        assert len(strides) == n_stages, "strides must have as many entries as we have resolution stages (n_stages). " \
                                         "Important: first entry is recommended to be 1, else we run strided conv drectly on the input"

        pool_op = get_matching_pool_op(conv_op, pool_type=pool_type) if pool_type != 'conv' else None

        do_channel_token = [False] * n_stages
        feature_map_sizes = []
        feature_map_size = input_size
        for s in range(n_stages):
            feature_map_sizes.append([i // j for i, j in zip(feature_map_size, strides[s])])
            feature_map_size = feature_map_sizes[-1]
            if np.prod(feature_map_size) <= features_per_stage[s]:
                do_channel_token[s] = True

        print(f"feature_map_sizes: {feature_map_sizes}")
        print(f"do_channel_token: {do_channel_token}")

        self.conv_pad_sizes = []
        for krnl in kernel_sizes:
            self.conv_pad_sizes.append([i // 2 for i in krnl])

        stem_channels = features_per_stage[0]
        self.stem = nn.Sequential(
            BasicResBlock(
                conv_op=conv_op,
                input_channels=input_channels,
                output_channels=stem_channels,
                norm_op=norm_op,
                norm_op_kwargs=norm_op_kwargs,
                kernel_size=kernel_sizes[0],
                padding=self.conv_pad_sizes[0],
                stride=1,
                nonlin=nonlin,
                nonlin_kwargs=nonlin_kwargs,
                use_1x1conv=True
            ),
            *[
                BasicBlockD(
                    conv_op=conv_op,
                    input_channels=stem_channels,
                    output_channels=stem_channels,
                    kernel_size=kernel_sizes[0],
                    stride=1,
                    conv_bias=conv_bias,
                    norm_op=norm_op,
                    norm_op_kwargs=norm_op_kwargs,
                    nonlin=nonlin,
                    nonlin_kwargs=nonlin_kwargs,
                ) for _ in range(n_blocks_per_stage[0] - 1)
            ]
        )

        input_channels = stem_channels

        stages = []
        mamba_layers = []
        for s in range(n_stages):
            stage = nn.Sequential(
                BasicResBlock(
                    conv_op=conv_op,
                    norm_op=norm_op,
                    norm_op_kwargs=norm_op_kwargs,
                    input_channels=input_channels,
                    output_channels=features_per_stage[s],
                    kernel_size=kernel_sizes[s],
                    padding=self.conv_pad_sizes[s],
                    stride=strides[s],
                    use_1x1conv=True,
                    nonlin=nonlin,
                    nonlin_kwargs=nonlin_kwargs
                ),
                *[
                    BasicBlockD(
                        conv_op=conv_op,
                        input_channels=features_per_stage[s],
                        output_channels=features_per_stage[s],
                        kernel_size=kernel_sizes[s],
                        stride=1,
                        conv_bias=conv_bias,
                        norm_op=norm_op,
                        norm_op_kwargs=norm_op_kwargs,
                        nonlin=nonlin,
                        nonlin_kwargs=nonlin_kwargs,
                    ) for _ in range(n_blocks_per_stage[s] - 1)
                ]
            )

            mamba_layers.append(
                MambaLayer(
                    # dim=np.prod(feature_map_sizes[s]) if do_channel_token[s] else features_per_stage[s],
                    dim=features_per_stage[s] if self.SSAS[s] == 'spiral' or self.SSAS[s] == 'b c h w t' or self.SSAS[s] == 'b c w h t' or self.SSAS[s] == 'b c t h w' else self.W[s],
                    channel_token=do_channel_token[s], SSAS=self.SSAS[s]
                )
            )

            stages.append(stage)
            input_channels = features_per_stage[s]

        self.mamba_layers = nn.ModuleList(mamba_layers)
        self.stages = nn.ModuleList(stages)
        self.output_channels = features_per_stage
        self.strides = [maybe_convert_scalar_to_list(conv_op, i) for i in strides]
        self.return_skips = return_skips

        self.conv_op = conv_op
        self.norm_op = norm_op
        self.norm_op_kwargs = norm_op_kwargs
        self.nonlin = nonlin
        self.nonlin_kwargs = nonlin_kwargs
        # self.dropout_op = dropout_op
        # self.dropout_op_kwargs = dropout_op_kwargs
        self.conv_bias = conv_bias
        self.kernel_sizes = kernel_sizes

    def forward(self, x):
        if self.stem is not None:
            x = self.stem(x)
        ret = []
        for s in range(len(self.stages)):
            x = self.stages[s](x)
            x = self.mamba_layers[s](x, r=False)
            ret.append(x)
        if self.return_skips:
            return ret
        else:
            return ret[-1]

    def compute_conv_feature_map_size(self, input_size):
        if self.stem is not None:
            output = self.stem.compute_conv_feature_map_size(input_size)
        else:
            output = np.int64(0)

        for s in range(len(self.stages)):
            output += self.stages[s].compute_conv_feature_map_size(input_size)
            input_size = [i // j for i, j in zip(input_size, self.strides[s])]

        return output


class UNetResDecoder(nn.Module):
    def __init__(self,
                 encoder,
                 num_classes,
                 n_conv_per_stage: Union[int, Tuple[int, ...], List[int]],
                 deep_supervision, nonlin_first: bool = False,
                 SSAS=None):
        super().__init__()
        self.SSAS = SSAS
        self.deep_supervision = deep_supervision
        self.encoder = encoder
        self.num_classes = num_classes
        n_stages_encoder = len(encoder.output_channels)
        if isinstance(n_conv_per_stage, int):
            n_conv_per_stage = [n_conv_per_stage] * (n_stages_encoder - 1)
        assert len(n_conv_per_stage) == n_stages_encoder - 1, "n_conv_per_stage must have as many entries as we have " \
                                                              "resolution stages - 1 (n_stages in encoder - 1), " \
                                                              "here: %d" % n_stages_encoder

        stages = []

        upsample_layers = []
        mamba_layers = []

        seg_layers = []
        for s in range(1, n_stages_encoder):
            input_features_below = encoder.output_channels[-s]
            input_features_skip = encoder.output_channels[-(s + 1)]
            stride_for_upsampling = encoder.strides[-s]

            upsample_layers.append(UpsampleLayer(
                conv_op=encoder.conv_op,
                input_channels=input_features_below,
                output_channels=input_features_skip,
                pool_op_kernel_size=stride_for_upsampling,
                mode='nearest'
            ))

            stages.append(nn.Sequential(
                BasicResBlock(
                    conv_op=encoder.conv_op,
                    norm_op=encoder.norm_op,
                    norm_op_kwargs=encoder.norm_op_kwargs,
                    nonlin=encoder.nonlin,
                    nonlin_kwargs=encoder.nonlin_kwargs,
                    input_channels=input_features_skip,
                    output_channels=input_features_skip,
                    kernel_size=encoder.kernel_sizes[-(s + 1)],
                    padding=encoder.conv_pad_sizes[-(s + 1)],
                    stride=1,
                    use_1x1conv=True
                ),
                *[
                    BasicBlockD(
                        conv_op=encoder.conv_op,
                        input_channels=input_features_skip,
                        output_channels=input_features_skip,
                        kernel_size=encoder.kernel_sizes[-(s + 1)],
                        stride=1,
                        conv_bias=encoder.conv_bias,
                        norm_op=encoder.norm_op,
                        norm_op_kwargs=encoder.norm_op_kwargs,
                        nonlin=encoder.nonlin,
                        nonlin_kwargs=encoder.nonlin_kwargs,
                    ) for _ in range(n_conv_per_stage[s - 1] - 1)
                ]
            ))

            seg_layers.append(encoder.conv_op(input_features_skip, num_classes, 1, 1, 0, bias=True))



        self.stages = nn.ModuleList(stages)
        self.upsample_layers = nn.ModuleList(upsample_layers)
        self.seg_layers = nn.ModuleList(seg_layers)

    def center_crop(self, x, target_size):
        """
        x: Tensor of shape (B, C, H, W)
        target_size: (target_h, target_w)
        """
        _, _, _, h, w = x.shape
        th, tw = target_size

        # 计算中心裁剪的位置
        i = (h - th) // 2
        j = (w - tw) // 2

        # 裁剪为目标大小
        return x[:, :, :, i:i + th, j:j + tw]

    def forward(self, skips):
        lres_input = skips[-1]
        # seg_outputs = []
        outputs = []
        for s in range(len(self.stages)):
            x = self.upsample_layers[s](lres_input)
            # x = torch.cat((x, skips[-(s+2)]), 1)
            skip = skips[-(s + 2)]
            # 如果尺寸不一致 → 自动 center crop 对齐
            if skip.shape[3] != x.shape[3] or skip.shape[4] != x.shape[4]:
                x = self.center_crop(x, (skip.shape[3], skip.shape[4]))

            # 相加
            x = x + skip
            # x = self.stages[s](x)

            if self.deep_supervision:
                outputs.append(x)
            elif s == (len(self.stages) - 1):
                outputs.append(x)

            lres_input = x

        outputs = outputs[::-1]

        if not self.deep_supervision:
            r = outputs[0]
        else:
            r = outputs

        return r

    def compute_conv_feature_map_size(self, input_size):
        skip_sizes = []
        for s in range(len(self.encoder.strides) - 1):
            skip_sizes.append([i // j for i, j in zip(input_size, self.encoder.strides[s])])
            input_size = skip_sizes[-1]

        assert len(skip_sizes) == len(self.stages)

        output = np.int64(0)
        for s in range(len(self.stages)):
            output += self.stages[s].compute_conv_feature_map_size(skip_sizes[-(s + 1)])
            output += np.prod([self.encoder.output_channels[-(s + 2)], *skip_sizes[-(s + 1)]], dtype=np.int64)
            if self.deep_supervision or (s == (len(self.stages) - 1)):
                output += np.prod([self.num_classes, *skip_sizes[-(s + 1)]], dtype=np.int64)
        return output

class ResidualConvUnit3D(nn.Module):
    """
    Residual Conv Unit for (B, C, T, H, W)
    """
    def __init__(self, channels, norm_op=nn.InstanceNorm3d):
        super().__init__()
        self.conv1 = nn.Conv3d(channels, channels, kernel_size=3, padding=1, bias=False)
        self.norm1 = norm_op(channels, affine=True)
        self.relu = nn.ReLU(inplace=True)

        self.conv2 = nn.Conv3d(channels, channels, kernel_size=3, padding=1, bias=False)
        self.norm2 = norm_op(channels, affine=True)

    def forward(self, x):
        out = self.relu(self.norm1(self.conv1(x)))
        out = self.norm2(self.conv2(out))
        return self.relu(out + x)

class FeatureFusionBlock3D(nn.Module):
    """
    Dual-RCU Feature Fusion Block (MambaMoE / RefineNet style)
    """
    def __init__(self, ch_high, ch_low, ch_out):
        super().__init__()

        # 通道对齐
        self.proj_high = nn.Conv3d(ch_high, ch_out, kernel_size=1, bias=False)
        self.proj_low  = nn.Conv3d(ch_low,  ch_out, kernel_size=1, bias=False)

        self.rcu1 = ResidualConvUnit3D(ch_out)
        self.rcu2 = ResidualConvUnit3D(ch_out)

    def forward(self, x_high, x_low):
        """
        x_high: (B, C_high, T, h, w)  低分辨率
        x_low : (B, C_low,  T, H, W)  高分辨率
        """

        # 1) 上采样（只对 H,W，不动 T）
        x_high = F.interpolate(
            x_high,
            size=(x_high.shape[2], x_low.shape[3], x_low.shape[4]),
            mode="trilinear",
            align_corners=False
        )

        # 2) 通道对齐
        x_high = self.proj_high(x_high)
        x_low  = self.proj_low(x_low)

        # 3) 低层特征预处理 + 相加
        x = x_high + self.rcu1(x_low)

        # 4) 融合后精炼
        x = self.rcu2(x)

        return x


class SpaSpeMamba(nn.Module):
    def __init__(self,
                 input_size: Tuple[int, ...]=[48, 160, 224],
                 input_channels: int=1,
                 n_stages: int=6,
                 # features_per_stage: Union[int, List[int], Tuple[int, ...]]=[32, 64, 128, 256, 320, 320],
                 features_per_stage: Union[int, List[int], Tuple[int, ...]]=[32, 64],
                 conv_op: Type[_ConvNd]=torch.nn.modules.conv.Conv3d,
                 # kernel_sizes: Union[int, List[int], Tuple[int, ...]]=[[1, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3], [3, 3, 3]],
                 kernel_sizes: Union[int, List[int], Tuple[int, ...]]=[[1, 3, 3], [3, 3, 3]],
                 # strides: Union[int, List[int], Tuple[int, ...]]=[[1, 1, 1], [1, 2, 2], [2, 2, 2], [2, 2, 2], [2, 2, 2], [1, 2, 2]],
                 strides: Union[int, List[int], Tuple[int, ...]]=[[1, 1, 1], [1, 2, 2]],
                 # n_conv_per_stage: Union[int, List[int], Tuple[int, ...]]=[2, 2, 2, 2, 2, 2],
                 n_conv_per_stage: Union[int, List[int], Tuple[int, ...]]=[2, 2],
                 num_classes: int=14,
                 # n_conv_per_stage_decoder: Union[int, Tuple[int, ...], List[int]]=[2, 2, 2, 2, 2],
                 n_conv_per_stage_decoder: Union[int, Tuple[int, ...], List[int]]=[2],
                 conv_bias: bool = True,
                 norm_op: Union[None, Type[nn.Module]] = torch.nn.modules.instancenorm.InstanceNorm3d,
                 norm_op_kwargs: dict = {'eps': 1e-05, 'affine': True},
                 dropout_op: Union[None, Type[_DropoutNd]] = None,
                 dropout_op_kwargs: dict = None,
                 nonlin: Union[None, Type[torch.nn.Module]] = torch.nn.modules.activation.LeakyReLU,
                 nonlin_kwargs: dict = {'inplace': True},
                 deep_supervision: bool = False,
                 stem_channels: int = None,
                #  SSAS = [
                #     [(0,1,2,3,4),(0,1,2,3,4)],
                #     [(0,1,4,2,3),(0,1,3,4,2)],
                #     [(0,1,2,4,3),(0,1,2,4,3)],
                #     [(0,1,3,4,2),(0,1,4,2,3)],
                #     [(0,1,3,2,4),(0,1,3,2,4)],
                #     [(0,1,4,3,2),(0,1,4,3,2)],
                # ],
                 SSAS=[
                     [(0, 1, 2, 3, 4), (0, 1, 2, 3, 4)],
                     [(0, 1, 4, 2, 3), (0, 1, 3, 4, 2)]
                 ],
                 hidden_dim=103,
                 patch_size=9
                 ):
        super().__init__()
        self.SSAS =SSAS
        n_blocks_per_stage = n_conv_per_stage
        if isinstance(n_blocks_per_stage, int):
            n_blocks_per_stage = [n_blocks_per_stage] * n_stages
        if isinstance(n_conv_per_stage_decoder, int):
            n_conv_per_stage_decoder = [n_conv_per_stage_decoder] * (n_stages - 1)

        for s in range(math.ceil(n_stages / 2), n_stages):
            n_blocks_per_stage[s] = 1

        for s in range(math.ceil((n_stages - 1) / 2 + 0.5), n_stages - 1):
            n_conv_per_stage_decoder[s] = 1


        assert len(n_blocks_per_stage) == n_stages, "n_blocks_per_stage must have as many entries as we have " \
                                                  f"resolution stages. here: {n_stages}. " \
                                                  f"n_blocks_per_stage: {n_blocks_per_stage}"
        assert len(n_conv_per_stage_decoder) == (n_stages - 1), "n_conv_per_stage_decoder must have one less entries " \
                                                                f"as we have resolution stages. here: {n_stages} " \
                                                                f"stages, so it should have {n_stages - 1} entries. " \
                                                                f"n_conv_per_stage_decoder: {n_conv_per_stage_decoder}"


        # self.encoder = ResidualMambaEncoder(
        #     input_size,
        #     input_channels,
        #     n_stages,
        #     features_per_stage,
        #     conv_op,
        #     kernel_sizes,
        #     strides,
        #     n_blocks_per_stage,
        #     conv_bias,
        #     norm_op,
        #     norm_op_kwargs,
        #     nonlin,
        #     nonlin_kwargs,
        #     # return_skips=True,
        #     return_skips=False,
        #     stem_channels=stem_channels,
        #     SSAS=self.SSAS
        # )

        self.encoder = ResidualMambaEncoder(
            input_size,
            input_channels,
            n_stages,
            features_per_stage,
            conv_op,
            kernel_sizes,
            strides,
            n_blocks_per_stage,
            conv_bias,
            norm_op,
            norm_op_kwargs,
            nonlin,
            nonlin_kwargs,
            hidden_dim,
            return_skips=True,
            stem_channels=stem_channels,
            SSAS=self.SSAS,
            patch_size=patch_size
        )

        # self.decoder = UNetResDecoder(self.encoder, num_classes, n_conv_per_stage_decoder, deep_supervision,
        #                               SSAS=self.SSAS)

        self.decoder = UNetResDecoder(self.encoder, num_classes, n_conv_per_stage_decoder, deep_supervision,SSAS=self.SSAS)
        self.conv_first = conv_op(1, input_channels, kernel_size=3, stride=1, padding=1, bias=True)
        self.conv_last = conv_op(input_channels ,out_channels=1,kernel_size=3,stride=1,padding=1, bias=True)
        # self.norm = norm_op(features_per_stage[-1], **norm_op_kwargs)
        # self.act = nonlin(**nonlin_kwargs)

        # self.cls_head = nn.Sequential(
        #     nn.Conv2d(in_channels=hidden_dim, out_channels=128, kernel_size=1, stride=1, padding=0),
        #     nn.GroupNorm(group_num, 128),
        #     nn.SiLU(),
        #     nn.Conv2d(in_channels=128, out_channels=num_classes, kernel_size=1, stride=1, padding=0))
        self.mlp_head = nn.Sequential(
            Reduce('b d h w -> b d', 'mean'),
            nn.LayerNorm(hidden_dim),
            nn.Linear(hidden_dim, num_classes)
        )

    def forward(self, x):
        # x = x.unsqueeze(1)
        x_first =self.conv_first(x)
        skips = self.encoder(x_first)
        # y = self.encoder(x_first)

        y = self.decoder(skips)
        # y = self.conv_last(y[0]+x_first).squeeze(1)
        # logits = self.mlp_head(y)
        y_1 = self.conv_last(y).squeeze(1)
        logits = self.mlp_head(y_1)
        return logits

    def compute_conv_feature_map_size(self, input_size):
        assert len(input_size) == convert_conv_op_to_dim(self.encoder.conv_op), "just give the image size without color/feature channels or " \
                                                                                "batch channel. Do not give input_size=(b, c, x, y(, z)). " \
                                                                                "Give input_size=(x, y(, z))!"
        return self.encoder.compute_conv_feature_map_size(input_size) + self.decoder.compute_conv_feature_map_size(input_size)


if __name__=='__main__':
    print(f"\n======== 正在计算模型指标=========")
    model_name='spaspemamba'
    model_index = 8

    data_set_name_list = ['UP', 'HanChuan', 'HongHu', 'Houston']
    data_name=data_set_name_list[3]
    patch_train_size=11
    if data_name == 'UP':
        time=103
        class_count=9
    elif data_name == 'HongHu':
        time=270
        class_count=22
    elif data_name == 'Houston':
        time=144
        class_count=15
    else:
        print("数据集错误")

    from model.get_model import get_model

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    net = get_model(model_name, data_name, patch_train_size, time, class_count, model_index, device)
    net.to(device)

    net.eval()
    # 1. 定义虚拟输入
    # 根据你原有代码中注释掉的 summary 部分，输入形状似乎是 (1, 1, time, patch_size, patch_size)
    # 如果报错，请根据你的模型实际 forward 接收的维度调整这里
    dummy_input = torch.randn(1, 1, time, patch_train_size, patch_train_size).to(device)

    # net.eval()
    flops, macs1, para = calculate_flops(model=net,
                                         input_shape=(1, 1, time, 11, 11), )
    # logger.info("para:{}\n,flops:{}".format(para, flops))
    print("para:{}\n,flops:{}".format(para, flops))

    from ptflops import get_model_complexity_info

    with torch.cuda.device(0):
        macs, params = get_model_complexity_info(net, (1, time, 11, 11), as_strings=True, print_per_layer_stat=True,
                                                 verbose=True)
    print('{:<30}  {:<8}'.format('Computational complexity: ', macs))
    print('{:<30}  {:<8}'.format('Number of parameters: ', params))

    # 2. 计算 #Param 和 FLOPS
    from thop import profile
    import time as t

    macs, params = profile(net, inputs=(dummy_input,), verbose=False)
    flops_g = 2 * macs / 1e9  # 转换为 GFLOPS
    params_m = params / 1e6  # 转换为 M

    for m in net.modules():
        # 清除残留的属性
        if hasattr(m, "total_ops"):
            del m.total_ops
        if hasattr(m, "total_params"):
            del m.total_params
        # 强制清空 forward hooks
        m._forward_hooks.clear()

    # 3. 计算 Memory (峰值显存)
    torch.cuda.reset_peak_memory_stats()
    with torch.no_grad():
        _ = net(dummy_input)
    memory_mb = torch.cuda.max_memory_allocated() / (1024 ** 2)

    # 4. 计算 Inference Time (推理耗时)
    # 预热
    for _ in range(50):
        with torch.no_grad():
            _ = net(dummy_input)

    # 测速
    iter_times = 100
    torch.cuda.synchronize()
    t_start = t.time()
    with torch.no_grad():
        for _ in range(iter_times):
            _ = net(dummy_input)
    torch.cuda.synchronize()
    inference_time_ms = (t.time() - t_start) / iter_times * 1000

    # 打印并记录日志
    metrics_str = (
        f"\n----------------------------------------\n"
        f"Model Metrics:\n"
        f"1. #Param.: {params_m:.2f} M\n"
        f"2. Memory : {memory_mb:.2f} MB\n"
        f"3. FLOPS  : {flops_g:.2f} G\n"
        f"4. Time   : {inference_time_ms:.2f} ms\n"
        f"----------------------------------------\n"
    )
    print(metrics_str)