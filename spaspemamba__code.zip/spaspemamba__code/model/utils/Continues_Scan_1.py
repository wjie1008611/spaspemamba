import torch
from einops import rearrange

# ============================================================
# 1. 生成 HW 平面上的螺旋索引
#    规则：
#    - 从中心开始
#    - 第二步：中心正上
#    - 顺时针向外扩张
#    - 适配奇偶尺寸（2x2 单独处理）
# ============================================================
def spiral_indices_hw(H, W):
    coords = []

    # --------- 确定中心 ---------
    if H % 2 == 1 and W % 2 == 1:
        r, c = H // 2, W // 2
    else:
        # 偶数尺寸（如 2x2）：选左上为起点，最稳定
        r, c = H // 2 - 1, W // 2 - 1

    coords.append((r, c))

    # --------- 方向：上 → 右 → 下 → 左（顺时针）---------
    directions = [
        (-1, 0),  # up
        (0, 1),   # right
        (1, 0),   # down
        (0, -1)   # left
    ]

    step = 1
    while len(coords) < H * W:
        for d in range(4):
            dr, dc = directions[d]
            for _ in range(step):
                r += dr
                c += dc
                if 0 <= r < H and 0 <= c < W:
                    coords.append((r, c))
                if len(coords) >= H * W:
                    break
            # 每两个方向，步长 +1
            if d % 2 == 1:
                step += 1
            if len(coords) >= H * W:
                break

    return coords


# ============================================================
# 2. 螺旋扫描（Forward）
#    输入:  (B, C, T, H, W)
#    输出:  (B, C, T, H, W) —— HW 按螺旋顺序展开后再 reshape
# ============================================================
# def spiral_scan_3d(x, SSAS ,connect=False):
def spiral_scan_3d(x):
    """
    Spiral scan only on (H, W) dimensions.

    Args:
        x: Tensor of shape (B, C, T, H, W)

    Returns:
        Tensor of shape (B, C, T, H, W) in spiral order
    """
    B, C, T, H, W = x.shape
    coords = spiral_indices_hw(H, W)

    seq = []
    for (r, c) in coords:
        seq.append(x[:, :, :, r, c])  # (B, C, T)

    seq = torch.stack(seq, dim=-1)   # (B, C, T, H*W)
    seq = seq.view(B, C, T, H, W)

    # if  not connect:
    #     seq = rearrange(x, 'b c t h w -> ' + SSAS, b=B, c=C, t=T, h=H, w=W)

    return seq


# ============================================================
# 3. 螺旋反恢复（Reverse）
#    输入:  (B, C, T, H, W) —— 螺旋顺序
#    输出:  (B, C, T, H, W) —— 原空间布局
# ============================================================
def rev_spiral_restore_3d(x):
    """
    Restore spatial layout from spiral order.

    Args:
        x: Tensor of shape (B, C, T, H, W)

    Returns:
        Tensor of shape (B, C, T, H, W) restored
    """
    # if connect == False:
    #     B = batch_size
    #     C, T, H, W = x.shape
    # else:
    #     B, C, T, H, W = x.shape

    B, C, T, H, W = x.shape

    coords = spiral_indices_hw(H, W)

    out = torch.zeros_like(x)
    flat = x.view(B, C, T, -1)

    for idx, (r, c) in enumerate(coords):
        out[:, :, :, r, c] = flat[:, :, :, idx]

    return out


# ============================================================
# 4. 简单测试（可选）
# ============================================================
if __name__ == "__main__":
    # 测试 3x3 / 5x5 / 9x9 / 2x2
    for size in [3, 5, 9, 2]:
        print(f"\nTesting size: {size}x{size}")
        x = torch.arange(size * size).view(1, 1, 1, size, size).float()
        y = spiral_scan_3d(x)
        z = rev_spiral_restore_3d(y)
        print("Original:")
        print(x.view(size, size))
        print("Spiral:")
        print(y.view(size, size))
        print("Restored:")
        print(z.view(size, size))
